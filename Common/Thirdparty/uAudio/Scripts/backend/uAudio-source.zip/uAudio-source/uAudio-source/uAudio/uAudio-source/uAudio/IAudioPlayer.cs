﻿namespace uAudio.uAudio_backend
{
    // DO not make this IAudioPlayer an abstract class...!!!!
    public interface IAudioPlayer : System.IDisposable
    {
        string current_TargetFile_Loaded { get; }
        System.String AudioTitle { get; }
        PlayBackState PlaybackState { get; }
        System.Action<PlayBackState> sendPlaybackState { get; set; }
        float Volume { get; set; }
        System.TimeSpan TotalTime { get; }
        System.TimeSpan CurrentTime { get; set; }
        int SongLength { get; }

        float Pan { get; set; }
        //System.Action PlayBackStopped { get; set; }
        void Pause();
        void Play(System.TimeSpan? OffsetStart=null);
        void Stop();
        void ChangeCurrentTime(System.TimeSpan timeIN);
        void LoadFile(string targetFile);
        void SetFile(string targetFile);
        System.Action SLEEP { get; set; }
    }

    public enum PlayBackState    // Stato della riproduzione
    {
        Stopped = 0,
        Playing = 1,
        Paused = 2,
    }
}
﻿using System;
using NAudio.Wave;
using System.Net;

namespace uAudio.uAudio_backend
{
    public partial class uAudio_Streaming : uAudio_backend.IAudioPlayer, IDisposable
    {
        #region vars
        public float minBufferTime = 2f;
        public float maxBufferTime = 20f;
        public System.Collections.IEnumerator myUpdateLoop;
        public System.Action sendPlaying;

        //public System.Action sendStartLoopPump;
        //public System.Action sendStopLoopPump;

        Action<PlayBackState> _sendPlaybackState;
        public Action<PlayBackState> sendPlaybackState
        {
            get
            {
                return _sendPlaybackState;
            }

            set
            {
                _sendPlaybackState = value;
            }
        }
        public int SongLength { get { return 0; } }

        public delegate void send(object sender, EventArgs e);
        public event send Disposed;

        public bool IsPause = false;
        public volatile StreamingPlaybackState playbackState;
        public uAudio_backend.IAudioPlayer my_uAudioPlayer2;
        public float startVolume;

        string target_URL;

        WebRequest webRequest;
        WebResponse responce;
        WebRequest webReply;

        System.IO.Stream responceStream;
        uAudioDemo.Mp3StreamingDemo.ReadFullyStream readFullyStream;

        byte[] temp_buffer = new byte[16384 * 4]; // needs to be big enough to hold a decompressed frame

        ISampleProvider output;

        volatile bool fullyDownloaded;
        bool error = false;
        public ISampleProvider reader;
        Wave16ToFloatProvider convert;

        BufferedWaveProvider bufferedWaveProvider;
        IMp3FrameDecompressor decompressor;

        public enum StreamingPlaybackState
        {
            Stopped,
            Playing,
            Buffering,
            Paused
        }
        string uAudio_backend.IAudioPlayer.current_TargetFile_Loaded
        {
            get
            { return target_URL; }
        }
        private void ShowError(string message)
        {
            UnityEngine.Debug.LogException(new System.Exception("AudioStreaming #asd33 ---" + message));
        }
        #endregion ---vars---

        #region con
        public uAudio_Streaming()
        {
            //myUpdateLoop = UpdateLoop();
        }
        #endregion ---con---

        #region Back end access
        public void Play(System.TimeSpan? OffsetStart=null)
        {
#if uAudio_debug
            UnityEngine.Debug.LogWarning("&t&");
#endif
            try
            {
                if (playbackState == StreamingPlaybackState.Stopped || (bufferedWaveProvider == null && reader == null))
                {
#if uAudio_debug
                    UnityEngine.Debug.LogWarning("&4 ");
#endif
                    if (bufferedWaveProvider != null)
                    {
#if uAudio_debug
                        UnityEngine.Debug.LogWarning("&p ");
#endif
                        bufferedWaveProvider.ClearBuffer();
                    }
                    else
                    {
#if uAudio_debug
                        UnityEngine.Debug.LogWarning("&r ");
#endif
                    }
                    playbackState = StreamingPlaybackState.Buffering;
#if uAudio_debug
                    UnityEngine.Debug.LogWarning("&q ");
#endif
                    //var myThreadPump = new System.Threading.Thread(new System.Threading.ThreadStart(delegate
                    //     {
                    Start_OpenWebStream(target_URL);
                    
                    //     }));
                    //myThreadPump.IsBackground = true;
                    //myThreadPump.Start();
                    //      StreamMp3("http://radio.reaper.fm/stream/");
                }
                else
                {
                    if (playbackState == StreamingPlaybackState.Playing)
                    {
#if uAudio_debug
                        UnityEngine.Debug.LogWarning("&2 ");
#endif
                        Pause();
                        if (sendPlaybackState != null)
                            sendPlaybackState(PlayBackState.Paused);

                    }
                    else
                    {
                        if (playbackState == StreamingPlaybackState.Paused)
                        {
#if uAudio_debug
                            UnityEngine.Debug.LogWarning("&b ");
#endif
                            my_uAudioPlayer2.Play();
                            if (sendPlaybackState != null)
                                sendPlaybackState(PlayBackState.Playing);

                        }
                    }
                }
                IsPause = false;

#if uAudio_debug
                UnityEngine.Debug.LogWarning("&w ");
#endif
            }
            catch
            {
                ShowError("#j756je65j565j56");
            }
        }

        public void Buffer()
        {
            try
            {
                playbackState = StreamingPlaybackState.Buffering;
                IsPause = false;
            }
            catch
            {
                ShowError("#6k7kr67krk7r67k");
            }
        }

        public void Pause()
        {
            try
            {
                playbackState = StreamingPlaybackState.Paused;

                IsPause = true;
                my_uAudioPlayer2.Pause();
            }
            catch
            {
                ShowError("#s9bdv9sv9dbsv");
            }
        }

        public void Stop()
        {
            try
            {
                halt();
            }
            catch
            {
                ShowError("#45gw45gwe45g45g");
            }
        }

        public bool HadError()
        {
            return error;
        }

        void halt()
        {
#if uAudio_debug
            UnityEngine.Debug.LogWarning("&halt&");
#endif
            IsPause = false;
            playbackState = StreamingPlaybackState.Stopped;


            if (readFullyStream != null)
            {
                try
                {
                    readFullyStream.Close();
                    readFullyStream.Dispose();
                }
                catch { error = true; }
                readFullyStream = null;
            }
            if (responceStream != null)
            {
                try
                {
                    responceStream.Close();
                    responceStream.Dispose();
                }
                catch { error = true; }
                responceStream = null;
            }
            if (webReply != null)
            {
                try
                {
                    webReply.Abort();
                }
                catch { error = true; }
                webReply = null;
            }
            if (responce != null)
            {
                try
                {
                    responce.Close();
                }
                catch { error = true; }
                responce = null;
            }
            if (webRequest != null)
            {
                try
                {
                    webRequest.Abort();
                }
                catch { error = true; }
                webRequest = null;
            }





            if (convert != null)
            {
                convert = null;
            }

            if (bufferedWaveProvider != null)
            {
                try
                {
                    bufferedWaveProvider.ClearBuffer();
                }
                catch { error = true; }
                bufferedWaveProvider = null;
            }

            if (decompressor != null)
            {
                try
                {
                    decompressor.Dispose();
                }
                catch { error = true; }
                decompressor = null;
            }
        }

        public bool IsPlaying
        {
            get { return playbackState == StreamingPlaybackState.Playing; }
        }

        float _volume = 0;
        public float Volume
        {
            get
            {
                if (convert != null)
                    return convert.Volume;
                else
                    return _volume;
            }
            set
            {
                if (convert != null)
                    convert.Volume = value;

                _volume = value;
            }
        }

        #endregion ---Back end access---

        #region webstream
        void Start_OpenWebStream(string url)
        {
            try
            {
                fullyDownloaded = false;

                if (webRequest != null)
                {
                    Exception ex = new Exception("uAudio_Streaming - Start_OpenWebStream() webRequest double called #iuvbgs87vbdv");
                    ShowError("uAudio_Streaming - Start_OpenWebStream() webRequest double called #iuvbgs87vbdv");
                    throw ex;
                }
#if uAudio_debug
                UnityEngine.Debug.LogWarning("&i ");
#endif
                webRequest = WebRequest.Create(url);
                //  webRequest.Timeout = 10000;
#if uAudio_debug
                UnityEngine.Debug.LogWarning("&o ");
#endif
                try
                {
                    //                    if (!BetaNativeThreadBuffering)
                    //                    {
                    //                        var myThreadPump = new System.Threading.Thread(new System.Threading.ThreadStart(delegate
                    //                         {

                    //#if uAudio_debug
                    //                            UnityEngine.Debug.LogWarning("&c ");
                    //#endif

                    //                            if (true) //alt build
                    //                            {
                    //                                 responce = webRequest.GetResponse();
                    //                                 {
                    //                                     ProcessWebReply(responce);
                    //                                 }
                    //                                 return;
                    //                             }
                    //                             else
                    //                             {
                    //#if uAudio_debug
                    //                                UnityEngine.Debug.LogWarning("&g ");
                    //                                 webRequest.BeginGetResponse(Start_OpenWebStream_Responce, webRequest);
                    //                                 UnityEngine.Debug.LogWarning("&f ");
                    //#endif
                    //                            }
                    //                         }));
                    //                        myThreadPump.IsBackground = true;
                    //                        myThreadPump.Start();
                    //                    }
                    //                    else
                    {
#if uAudio_debug
                        UnityEngine.Debug.LogWarning("&c ");
#endif
                        //  if (targetWindows)
                        webRequest.BeginGetResponse(Start_OpenWebStream_Responce, webRequest);
                        //else
                        //{
                        //    responce = webRequest.GetResponse();
                        //    {
                        //        ProcessWebReply(responce);
                        //    }
                        //}
                    }
                }
                catch (WebException e)
                {
                    if (e.Status != WebExceptionStatus.RequestCanceled)
                    {
                        ShowError("#9c8hs9d8hcsdcsd" + e.Message);
                        error = true;
                    }

                    playbackState = StreamingPlaybackState.Stopped;
                    return;
                }
            }
            catch (System.Exception ex)
            {
#if uAudio_debug
                UnityEngine.Debug.LogWarning("&x ");
#endif
                ShowError("#f445f45");
                ShowError(ex.Message);
                error = true;
            }
#if uAudio_debug
            UnityEngine.Debug.LogWarning("&n ");
#endif
        }
        public bool BetaNativeThreadBuffering = false;

        private void Start_OpenWebStream_Responce(IAsyncResult asyncResult)
        {
            try
            {
#if uAudio_debug
                UnityEngine.Debug.LogWarning("#0 ");
#endif
                //  UnityEngine.Debug.LogWarning("webReply:"+ webReply.ToString());
                if (webReply == null)
                {
#if uAudio_debug
                    UnityEngine.Debug.LogWarning("#a ");
#endif

                    webReply = ((WebRequest)asyncResult.AsyncState);

                    try
                    {
                        responce = webReply.GetResponse();
                    }
                    catch
                    {
                        UnityEngine.Debug.LogError("uAudio_Streamer - WebRequest fail - maybe no web connection #i78g8dsgvsvd");
                    }

                    {
                        ProcessWebReply(responce);
                        try
                        {
                            if (asyncResult != null)
                                if (!asyncResult.IsCompleted)
                                    webRequest.EndGetResponse(asyncResult);
                        }
                        catch
                        {
                            ShowError("uAudio_Streaming - Force end webRequest.asyncResult");
                        }
                    }
                }
                else
                {
                    UnityEngine.Debug.LogException(new System.Exception("uAudio Streaming - Web Call fail"));
                    playbackState = StreamingPlaybackState.Stopped;
                }
            }
            catch (System.Exception ex)
            {
                UnityEngine.Debug.LogException(ex);
                playbackState = StreamingPlaybackState.Stopped;
                responceStream = null;
                return;
            }
        }

        public bool forceBuffering = false;
        void ProcessWebReply(WebResponse reqestIN)
        {
            try
            {
                if (reqestIN != null)
                {
                    if (reqestIN.ContentLength == 0)
                    {
                        playbackState = StreamingPlaybackState.Stopped;
                        return;
                    }

                    decompressor = null;
#if uAudio_debug
                    UnityEngine.Debug.LogWarning("#b");
#endif
                    try
                    {
                        responceStream = reqestIN.GetResponseStream();

                        readFullyStream = new uAudioDemo.Mp3StreamingDemo.ReadFullyStream(responceStream);
                        readFullyStream.stream_CanSeek = false;
                        if (targetWindows)//windows)
                        {
                            do
                            {
                                if (IsBufferNearlyFull || (IsPause && !forceBuffering))
                                {
                                    System.Threading.Thread.Sleep(500);
                                }

                                Mp3Frame frame;

                                try
                                {
                                    frame = Mp3Frame.LoadFromStream(readFullyStream);
                                }
                                catch (System.IO.EndOfStreamException)
                                {
                                    // broken frame - happens now and then
                                    // ignore it and move on : )
                                    continue;

                                    //frame = null;
                                    //  ShowError("done $67fsfd67");
                                    //           fullyDownloaded = true;
                                    // reached the end of the MP3 file / stream
                                    //         break;
                                }
                                catch (WebException)
                                {
                                    // probably we have aborted download from the GUI thread
                                    break;
                                }

                                if (frame == null)
                                {
                                    if (PlaybackState == PlayBackState.Playing)
                                        ShowError("broken frame");
                                }
                                else
                                {
                                    try
                                    {
                                        if (decompressor == null)
                                        {
#if uAudio_debug
                                            UnityEngine.Debug.LogWarning("#c");
#endif
                                            // don't think these details matter too much - just help ACM select the right codec
                                            // however, the buffered provider doesn't know what sample rate it is working at
                                            // until we have a frame

                                            //decompressor = CreateFrameDecompressor(frame);
                                            //bufferedWaveProvider = new BufferedWaveProvider(decompressor.OutputFormat);
                                            //bufferedWaveProvider.BufferDuration = TimeSpan.FromSeconds(maxBufferTime); // allow us to get well ahead of ourselves
                                            //VolumeWaveProvider16 convert2 = new VolumeWaveProvider16(bufferedWaveProvider);
                                            //convert2.Volume = _volume;
                                            //output = new NAudio.Wave.SampleProviders.SampleChannel(convert2);

                                            decompressor = CreateFrameDecompressor(frame);
                                            bufferedWaveProvider = new BufferedWaveProvider(decompressor.OutputFormat);
                                            bufferedWaveProvider.BufferDuration = TimeSpan.FromSeconds(maxBufferTime); // allow us to get well ahead of ourselves
                                            convert = new Wave16ToFloatProvider(bufferedWaveProvider);
                                            convert.Volume = _volume;
                                            output = new NAudio.Wave.SampleProviders.SampleChannel(convert);
                                            reader = output;
                                            // key moved
                                            //   my_uAudioPlayer2.fireOutSide = ReadData;

                                            // start the loop update
                                            if (sendPlaybackState != null)
                                                sendPlaybackState(PlayBackState.Playing);

                                            runPlay = true;
                                        }
                                        int decompressed = decompressor.DecompressFrame(frame, temp_buffer, 0);
                                        bufferedWaveProvider.AddSamples(temp_buffer, 0, decompressed);
#if uAudio_debug
                                        UnityEngine.Debug.LogWarning(".");
#endif

                                    }
                                    catch (System.Exception ex)
                                    {
                                        UnityEngine.Debug.LogException(new System.Exception("uAudio_Streaming - Start_OpenWebStream_Responce #87sgfv876fsdv78dsv"));
                                        UnityEngine.Debug.LogException(ex);
                                    }
                                }
                            }
                            while (playbackState != StreamingPlaybackState.Stopped && !fullyDownloaded);

                        }
                        else
                        {
                            //System.IO.MemoryStream m = new System.IO.MemoryStream();
                            //System.IO.MemoryStream br = new System.IO.MemoryStream();
                            //System.Threading.Thread t = new System.Threading.Thread(new System.Threading.ThreadStart(delegate
                            //{
                            //bool once = false;
                            //NAudio.Utils.CircularBuffer cb = new NAudio.Utils.CircularBuffer(1024 * 1024);
                            ////readFullyStream.Read(buff, 0, buff.Length);
                            //System.IO.Stream ms = new System.IO.MemoryStream();
                            //System.IO.Stream bs = new System.IO.BufferedStream(ms);




                            //while (playbackState != StreamingPlaybackState.Stopped)
                            //{
                            //readFullyStream.Read(buff, 0, buff.Length);
                            //ms.Write(buff, 0, buff.Length);
                            //if (!once)
                            //{
                            //System.Threading.Thread.Sleep(500);
                            while (readFullyStream.Length < 1024 * 16)
                            {
                                System.Threading.Thread.SpinWait(2);

                            }
                            //once = true;
                            byte[] buff = new byte[1024 * 16];
                            NLayer.MpegFile m = new NLayer.MpegFile(readFullyStream);
                            reader = m;
                            m.ReadSamples(buff, 0, buff.Length);
                            //bs.Position = 0;
                            output = reader;

                            //////int decompressed = decompressor.DecompressFrame(m, temp_buffer, 0);
                            //bufferedWaveProvider.AddSamples(buff, 0, buff.Length);
                            // reset

                            if (readFullyStream.CanSeek)
                                readFullyStream.Position = 0;

                            runPlay = true;
                            //    }
                            //}
                            //        }));
                            //t.IsBackground = true;
                            //t.Start();


                        }
                    }
                    catch (System.Exception ex)
                    {
                        ShowError("error #vieronvoer " + ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                ShowError("error #4h54h556h5 " + ex.Message);
            }
#if uAudio_debug
            UnityEngine.Debug.LogWarning(System.Environment.NewLine + System.Environment.NewLine + "runPlay" + System.Environment.NewLine);
#endif
        }
        public bool runPlay = false;
        public void ReadData(float[] data)
        {
            if (output != null)
            {
                output.Read(data, 0, data.Length);
            }
        }
        #endregion ---webstream---

        #region func
        public void ChangeCurrentTime(TimeSpan timeIN)
        {
            UnityEngine.Debug.LogException(new System.Exception("uAudio_Streaming - ChangeCurrentTime #8h0shd9v8hsd"));
            
        }
        public void SkipForward(int bytesToSkip)
        {
            bufferedWaveProvider.Advance(bytesToSkip);
        }
        public void LoadFile(string targetFile)
        {
            target_URL = targetFile;
            my_uAudioPlayer2.SetFile(target_URL);
        }

        public void SetFile(string targetFile)
        {
            target_URL = targetFile;
            my_uAudioPlayer2.SetFile(target_URL);
        }
        private bool IsBufferNearlyFull
        {
            get
            {
                return bufferedWaveProvider != null &&
                       bufferedWaveProvider.BufferLength - bufferedWaveProvider.BufferedBytes
                       < bufferedWaveProvider.WaveFormat.AverageBytesPerSecond / 4;
            }
        }

        public string AudioTitle
        {
            get
            {
                return target_URL;
            }
        }

        public PlayBackState PlaybackState
        {
            get
            {
                if (playbackState == StreamingPlaybackState.Playing)
                    return PlayBackState.Playing;
                else
                    return PlayBackState.Paused;
            }
        }

        public TimeSpan TotalTime
        {
            get
            {
                return TimeSpan.Zero;
            }
        }

        public TimeSpan CurrentTime
        {
            get
            {
                return TimeSpan.Zero;
            }

            set
            {
                // throw new NotImplementedException();
            }
        }

        public float Pan
        {
            get
            {
                ShowError("uAudio_Streaming - Pan #v87sfd76v6sd");
                return 0;
            }

            set
            {
                ShowError("uAudio_Streaming - Pan #f6sa76cf76sac");
            }
        }

        public Action PlayBackStopped
        {
            get
            {
                ShowError("uAudio_Streaming - PlayBackStopped #a7gfv876asvas");
                return null;
            }

            set
            {
                ShowError("uAudio_Streaming - PlayBackStopped #97vasr8as8va");
            }
        }

        public Action SLEEP
        {
            get
            {
                ShowError("SLEEP #h9dsvd");
                throw new NotImplementedException();
            }

            set
            {
                ShowError("SLEEP #h9dsvd");
                throw new NotImplementedException();
            }
        }

        private static IMp3FrameDecompressor CreateFrameDecompressor(Mp3Frame frame)
        {
            WaveFormat waveFormat = new Mp3WaveFormat(frame.SampleRate, frame.ChannelMode == ChannelMode.Mono ? 1 : 2,
                frame.FrameLength, frame.BitRate);
            return new AcmMp3FrameDecompressor(waveFormat);
        }
        #endregion ---func---

        #region GUI
        private void buttonPause_Click(object sender, EventArgs e)
        {
            if (playbackState == StreamingPlaybackState.Playing || playbackState == StreamingPlaybackState.Buffering)
            {
                Pause();
            }
        }

        private void ShowBufferState(double totalSeconds)
        {
            //            labelBuffered.Text = String.Format("{0:0.0}s", totalSeconds);
            //            progressBarBuffer.Value = (int)(totalSeconds * 1000);
        }
        #endregion ---GUI---

        #region loop
        private void OnPlaybackStopped(object sender, StoppedEventArgs e)
        {
            ShowError("uAudio_Streaming - OnPlaybackStopped #c7asdc765adscas");
        }
        public double BufferedTime
        {
            get
            {
                if (bufferedWaveProvider != null)
                    //if(bufferedWaveProvider.BufferedDuration != null)
                    return bufferedWaveProvider.BufferedDuration.TotalSeconds;
                else
                    return -1;
            }
        }

        public void callPlay(System.TimeSpan? OffsetStart)
        {
#if uAudio_debug
            UnityEngine.Debug.Log(System.Environment.NewLine + "--------------" + System.Environment.NewLine);
            UnityEngine.Debug.Log(System.Environment.NewLine + "Play" + System.Environment.NewLine);
            UnityEngine.Debug.Log(System.Environment.NewLine + "--------------" + System.Environment.NewLine);
#endif
            my_uAudioPlayer2.Play(OffsetStart);
        }

        public bool targetWindows = false;

        System.Collections.IEnumerator UpdateLoop()
        {
            while (!runPlay)
            {
                yield return new UnityEngine.WaitForSeconds(.1f);
            }
            if (runPlay)
            {
                //runPlay = false;
                
                callPlay(CurrentTime);
            }
            //Play();
            if (sendPlaying != null)
                sendPlaying();
#if uAudio_debug
            UnityEngine.Debug.Log(System.Environment.NewLine + "Start read Loop:" + System.Environment.NewLine);
#endif
            do
            {
                try
                {
                    if (playbackState != StreamingPlaybackState.Stopped && playbackState != StreamingPlaybackState.Paused)
                    {

                        if (!targetWindows || bufferedWaveProvider != null)
                        {
                            if (targetWindows)
                            {
                                double bufferedSeconds;
                                bufferedSeconds = bufferedWaveProvider.BufferedDuration.TotalSeconds;
                                ShowBufferState(bufferedSeconds);
                                if (bufferedSeconds < minBufferTime)
                                {
                                    continue;
                                    // buffering
#if uAudio_debug
                                    UnityEngine.Debug.Log(System.Environment.NewLine + "buffer: ^. ");
#endif
                                }
                                if (fullyDownloaded && bufferedSeconds == 0)
                                {
                                    try
                                    {
#if uAudio_debug
                                        UnityEngine.Debug.Log(System.Environment.NewLine + "over: ^q ");
#endif
                                        playbackState = StreamingPlaybackState.Stopped;
                                        halt();
                                    }
                                    catch
                                    {
                                        ShowError("uAudio_Streaming - UpdateLoop #sa86cras76rca");
                                    }
                                }
                            }

                            // make it stutter less if we buffer up a decent amount before playing
                            //                            if (playbackState == StreamingPlaybackState.Buffering)//&& bufferedSeconds > 4 )
                            //                            {
                            //#if uAudio_debug
                            //                                UnityEngine.Debug.LogWarning("&a&");
                            //#endif
                            //                                ShowError("tic-Play");
                            //                                playbackState = StreamingPlaybackState.Paused;
                            //                                Play();
                            //                            }
                        }
                        else
                        {
#if uAudio_debug
                            //System.Threading.Thread.Sleep(1000);
                            if (responceStream == null)
                            {
                                UnityEngine.Debug.Log(System.Environment.NewLine + "no buffer provider: ^webReply ");

                            }
                            else

                                UnityEngine.Debug.Log(System.Environment.NewLine + "no buffer provider: ^xx ");
#endif
                        }
                    }
                }
                catch
                {
                    ShowError("#34c3434");
                }
                yield return new UnityEngine.WaitForSeconds(.1f);
            }
            while (targetWindows && playbackState != StreamingPlaybackState.Stopped);
#if uAudio_debug
            UnityEngine.Debug.Log(System.Environment.NewLine + "end read loop: ^.x ");
#endif
            try
            {
                if (_sendPlaybackState != null)
                    _sendPlaybackState(PlayBackState.Stopped);
            }
            catch
            {
                UnityEngine.Debug.LogWarning("_sendPlaybackState(PlayBackState.Stopped) #vwerb4k78ktkj");
            }
        }
        #endregion ---loop---

        #region thread stuff
        //void CallUnityThread()
        //{
        //    ThreadPump.MainThreadPump.AddFunction_Unity(_CallUnityThread_fire());
        //}
        //System.Collections.IEnumerator _CallUnityThread_fire()
        //{
        //    if (sendUpdate != null)
        //        sendUpdate();
        //    yield return null;
        //}
        #endregion ---thread stuff---

        #region Dispose
        bool DisposedDone = false;
        public void Dispose()
        {
            try
            {
                if (!DisposedDone)
                {
                    DisposedDone = true;
                    try
                    {
                        halt();
                    }
                    catch
                    {
                        ShowError("#grtr6556j56j");
                    }
                    sendPlaying = null;

                    if (webRequest != null)
                    {
                        try
                        {
                            webRequest.Abort();
                            webRequest = null;
                        }
                        catch
                        {
                            ShowError("Dispose - #8f6sd87fsdf");
                        }
                    }

                    if (responceStream != null)
                    {
                        try
                        {
                            responceStream.Close();
                            responceStream = null;
                        }
                        catch
                        {
                            ShowError("Dispose - #8f6sd87fsdf");
                        }
                    }

                    Disposed = null;

                    _sendPlaybackState = null;
                    if (Disposed != null)
                    {
                        Disposed(this, new EventArgs());
                        Disposed = null;
                    }
                }
            }
            catch
            {
                ShowError("#xcw2434");
                error = true;
            }
        }
        #endregion ---Dispose---
    }
}
//using System;
 //using NAudio.Wave;
 //using System.Net;

//namespace uAudio.uAudio_backend
//{
//    public partial class uAudio_Streaming : uAudio_backend.IAudioPlayer, IDisposable
//    {
//        #region vars
//        public float minBufferTime = 2f;
//        public float maxBufferTime = 20f;
//        public System.Collections.IEnumerator myUpdateLoop;
//        public System.Action sendPlaying;

//        public System.Action sendStartLoopPump;
//        public System.Action sendStopLoopPump;
//        public delegate void send(object sender, EventArgs e);
//        public event send Disposed;

//        public bool IsPause = false;
//        public volatile StreamingPlaybackState playbackState;
//        public uAudio_backend.IAudioPlayer my_uAudioPlayer2;
//        public float startVolume;

//        string target_URL;

//        WebRequest webReply;
//        WebRequest webRequest;
//        WebResponse responce;
//        System.IO.Stream responceStream;
//        uAudioDemo.Mp3StreamingDemo.ReadFullyStream readFullyStream;
//        byte[] temp_buffer = new byte[16384 * 4]; // needs to be big enough to hold a decompressed frame

//        ISampleProvider output;

//        volatile bool fullyDownloaded;
//        bool error = false;
//        public NLayer.MpegFile reader;
//        Wave16ToFloatProvider convert;

//        BufferedWaveProvider bufferedWaveProvider;
//        IMp3FrameDecompressor decompressor;

//        public enum StreamingPlaybackState
//        {
//            Stopped,
//            Playing,
//            Buffering,
//            Paused
//        }
//        string uAudio_backend.IAudioPlayer.current_TargetFile_Loaded
//        {
//            get
//            { return target_URL; }
//        }
//        private void ShowError(string message)
//        {
//            UnityEngine.Debug.LogException(new System.Exception("AudioStreaming #asd33 ---" + message));
//        }
//        #endregion ---vars---

//        #region con
//        public uAudio_Streaming()
//        {
//            //myUpdateLoop = UpdateLoop();
//        }
//        #endregion ---con---

//        #region Back end access
//        public void Play()
//        {
//#if uAudio_debug
//            UnityEngine.Debug.LogWarning("&t&");
//#endif
//            try
//            {
//                if (playbackState == StreamingPlaybackState.Stopped || (bufferedWaveProvider==null&& reader==null))
//                {
//#if uAudio_debug
//                    UnityEngine.Debug.LogWarning("&4 ");
//#endif
//                    if (bufferedWaveProvider != null)
//                    {
//#if uAudio_debug
//                        UnityEngine.Debug.LogWarning("&p ");
//#endif
//                        bufferedWaveProvider.ClearBuffer();
//                    }
//                    else
//                    {
//#if uAudio_debug
//                        UnityEngine.Debug.LogWarning("&r ");
//#endif
//                    }
//                    playbackState = StreamingPlaybackState.Buffering;
//#if uAudio_debug
//                    UnityEngine.Debug.LogWarning("&q ");
//#endif
//                    //var myThreadPump = new System.Threading.Thread(new System.Threading.ThreadStart(delegate
//                    //     {
//                             Start_OpenWebStream(target_URL);
//                    //     }));
//                    //myThreadPump.IsBackground = true;
//                    //myThreadPump.Start();
//                    //      StreamMp3("http://radio.reaper.fm/stream/");
//                }
//                else
//                {
//                    if (playbackState == StreamingPlaybackState.Playing)
//                    {
//#if uAudio_debug
//                        UnityEngine.Debug.LogWarning("&2 ");
//#endif
//                        Pause();
//                    }
//                    else
//                    {
//                        if (playbackState == StreamingPlaybackState.Paused)
//                        {
//#if uAudio_debug
//                            UnityEngine.Debug.LogWarning("&b ");
//#endif
//                            my_uAudioPlayer2.Play();
//                        }
//                    }
//                }
//                IsPause = false;

//#if uAudio_debug
//                UnityEngine.Debug.LogWarning("&w ");
//#endif
//            }
//            catch
//            {
//                ShowError("#j756je65j565j56");
//            }
//        }

//        public void Buffer()
//        {
//            try
//            {
//                playbackState = StreamingPlaybackState.Buffering;
//                IsPause = false;
//            }
//            catch
//            {
//                ShowError("#6k7kr67krk7r67k");
//            }
//        }

//        public void Pause()
//        {
//            try
//            {
//                playbackState = StreamingPlaybackState.Paused;
//                IsPause = true;
//                my_uAudioPlayer2.Pause();
//            }
//            catch
//            {
//                ShowError("#s9bdv9sv9dbsv");
//            }
//        }

//        public void Stop()
//        {
//            try
//            {
//                halt();
//            }
//            catch
//            {
//                ShowError("#45gw45gwe45g45g");
//            }
//        }

//        public bool HadError()
//        {
//            return error;
//        }

//        void halt()
//        {
//#if uAudio_debug
//            UnityEngine.Debug.LogWarning("&halt&");
//#endif
//            IsPause = false;
//            playbackState = StreamingPlaybackState.Stopped;
//            output = null;
//            if (reader != null)
//            {
//                try
//                {
//                    reader.Dispose();
//                }
//                catch { error = true; }
//                reader = null;
//            }
//            if (readFullyStream != null)
//            {
//                try
//                {
//                    readFullyStream.Dispose();
//                }
//                catch { error = true; }
//                readFullyStream = null;
//            }

//            if (responceStream != null)
//            {
//                try
//                {
//                    responceStream.Close();
//                }
//                catch { error = true; }
//                responceStream = null;
//            }
//            if (webRequest != null)
//            {
//                try
//                {
//                    webRequest.Abort();
//                }
//                catch { error = true; }
//                webRequest = null;
//            }


//            if (webReply != null)
//            {
//                try
//                {
//                    webReply.Abort();
//                }
//                catch { error = true; }
//                webReply = null;
//            }

//            if (convert != null)
//            {
//                convert = null;
//            }

//            if (bufferedWaveProvider != null)
//            {
//                try
//                {
//                    bufferedWaveProvider.ClearBuffer();
//                }
//                catch { error = true; }
//                bufferedWaveProvider = null;
//            }

//            if (decompressor != null)
//            {
//                try
//                {
//                    decompressor.Dispose();
//                }
//                catch { error = true; }
//                decompressor = null;
//            }
//        }

//        public bool IsPlaying
//        {
//            get { return playbackState == StreamingPlaybackState.Playing; }
//        }

//        float _volume = 0;
//        public float Volume
//        {
//            get
//            {
//                if (convert != null)
//                    return convert.Volume;
//                else
//                    return _volume;
//            }
//            set
//            {
//                if (convert != null)
//                    convert.Volume = value;

//                _volume = value;
//            }
//        }

//        #endregion ---Back end access---

//        #region webstream
//        void Start_OpenWebStream(string url)
//        {
//            try
//            {
//                fullyDownloaded = false;

//                if (webRequest != null)
//                {
//                    Exception ex = new Exception("uAudio_Streaming - Start_OpenWebStream() webRequest double called #iuvbgs87vbdv");
//                    ShowError("uAudio_Streaming - Start_OpenWebStream() webRequest double called #iuvbgs87vbdv");
//                    throw ex;
//                }
//#if uAudio_debug
//                UnityEngine.Debug.LogWarning("&i ");
//#endif
//                webRequest = WebRequest.Create(url);
//                //  webRequest.Timeout = 10000;
//#if uAudio_debug
//                UnityEngine.Debug.LogWarning("&o ");
//#endif
//                try
//                {
//                    //                    if (!BetaNativeThreadBuffering)
//                    //                    {
//                    var myThreadPump = new System.Threading.Thread(new System.Threading.ThreadStart(delegate
//                     {

//                         //#if uAudio_debug
//                         //                            UnityEngine.Debug.LogWarning("&c ");
//                         //#endif

//                         //                            if (true) //alt build
//                         //                            {
//                         //responce = webRequest.GetResponse();
//                         //{
//                         //    ProcessWebReply(responce);
//                         //}
//                         //                                 return;
//                         //                             }
//                         //                             else
//                         //                             {
//                         //#if uAudio_debug
//                         //                                UnityEngine.Debug.LogWarning("&g ");
//                         webRequest.BeginGetResponse(Start_OpenWebStream_Responce, webRequest);
//                         //                                 UnityEngine.Debug.LogWarning("&f ");
//                         //#endif
//                         //                            }
//                     }));
//                    myThreadPump.IsBackground = true;
//                    myThreadPump.Start();
//                    //                    }
//                    //                    else
//                    {
//#if uAudio_debug
//                        UnityEngine.Debug.LogWarning("&c ");
//#endif
//                        //webRequest.BeginGetResponse(Start_OpenWebStream_Responce, webRequest);
//                        //responce = webRequest.GetResponse();
//                        //{
//                        //    ProcessWebReply(responce);
//                        //}
//                    }
//                }
//                catch (WebException e)
//                {
//                    if (e.Status != WebExceptionStatus.RequestCanceled)
//                    {
//                        ShowError("#9c8hs9d8hcsdcsd" + e.Message);
//                        error = true;
//                    }

//                    playbackState = StreamingPlaybackState.Stopped;
//                    return;
//                }
//            }
//            catch(System.Exception ex)
//            {
//#if uAudio_debug
//                UnityEngine.Debug.LogWarning("&x ");
//#endif
//                ShowError("#f445f45");
//                ShowError(ex.Message);
//                error = true;
//            }
//#if uAudio_debug
//            UnityEngine.Debug.LogWarning("&n ");
//#endif
//        }
//        public bool BetaNativeThreadBuffering = false;

//        private void Start_OpenWebStream_Responce(IAsyncResult asyncResult)
//        {
//            try
//            {
//#if uAudio_debug
//                UnityEngine.Debug.LogWarning("#0 ");
//#endif
//                //  UnityEngine.Debug.LogWarning("webReply:"+ webReply.ToString());
//                if (webReply == null)
//                {
//#if uAudio_debug
//                    UnityEngine.Debug.LogWarning("#a ");
//#endif

//                    webReply = ((WebRequest)asyncResult.AsyncState);
//                    responce = webReply.GetResponse();
//                    {
//                        ProcessWebReply(responce);
//                        try
//                        {
//                            if (asyncResult != null)
//                                if (!  asyncResult.IsCompleted)
//                                webRequest.EndGetResponse(asyncResult);
//                        }
//                        catch
//                        {
//                            ShowError("uAudio_Streaming - Force end webRequest.asyncResult");
//                        }
//                    }
//                }
//                else
//                {
//                    UnityEngine.Debug.LogException(new System.Exception("uAudio Streaming - Web Call fail"));
//                    playbackState = StreamingPlaybackState.Stopped;
//                }
//            }
//            catch (System.Exception ex)
//            {
//                UnityEngine.Debug.LogException(ex);
//                playbackState = StreamingPlaybackState.Stopped;
//                responceStream = null;
//                return;
//            }
//        }

//        public            bool forceBuffering = false;
//        void ProcessWebReply(WebResponse reqestIN)
//        {
//            try
//            {

//                if (reqestIN != null)
//                {
//                    if (reqestIN.ContentLength == 0)
//                    {
//                        playbackState = StreamingPlaybackState.Stopped;
//                        return;
//                    }

//                    decompressor = null;
//#if uAudio_debug
//                    UnityEngine.Debug.LogWarning("#b");
//#endif
//                    try
//                    {
//                        responceStream = reqestIN.GetResponseStream();
//                        {
//                            if (!responceStream.CanRead)
//                                throw new Exception("FSFASDF");

//                             readFullyStream = new uAudioDemo.Mp3StreamingDemo.ReadFullyStream(responceStream);
//                            {
//                           //     do
//                                {
//                                    //if (IsBufferNearlyFull || (IsPause && !forceBuffering))
//                                    //{
//                                    //    System.Threading.Thread.Sleep(500);
//                                    //}
//                                    //else
//                                    if(targetWindows)//windows)
//                                    {
//                                        Mp3Frame frame;
//                                        try
//                                        {
//                                            frame = Mp3Frame.LoadFromStream(readFullyStream);
//                                        }
//                                        catch (System.IO.EndOfStreamException)
//                                        {
//                                            // broken frame - happens now and then
//                                            // ignore it and move on : )
//                                            frame = null;

//                                            //frame = null;
//                                            //  ShowError("done $67fsfd67");
//                                            //           fullyDownloaded = true;
//                                            // reached the end of the MP3 file / stream
//                                            //         break;
//                                        }
//                                        catch (WebException)
//                                        {
//                                            // probably we have aborted download from the GUI thread
//                                            frame = null;
//                                        }

//                                        if (frame == null)
//                                        {
//                                            if(PlaybackState == PlayBackState.Playing)
//                                                ShowError("broken frame");
//                                        }
//                                        else
//                                        {
//                                            try
//                                            {
//                                                if (decompressor == null)
//                                                {
//#if uAudio_debug
//                                                    UnityEngine.Debug.LogWarning("#c");
//#endif
//                                                    // don't think these details matter too much - just help ACM select the right codec
//                                                    // however, the buffered provider doesn't know what sample rate it is working at
//                                                    // until we have a frame

//                                                    decompressor = CreateFrameDecompressor(frame);
//                                                    bufferedWaveProvider = new BufferedWaveProvider(decompressor.OutputFormat);
//                                                    bufferedWaveProvider.BufferDuration = TimeSpan.FromSeconds(maxBufferTime); // allow us to get well ahead of ourselves
//                                                    VolumeWaveProvider16 convert2 = new VolumeWaveProvider16(bufferedWaveProvider);
//                                                    convert2.Volume = _volume;
//                                                    output = new NAudio.Wave.SampleProviders.SampleChannel(convert2);




//                                                    //decompressor = CreateFrameDecompressor(frame);
//                                                    //bufferedWaveProvider = new BufferedWaveProvider(decompressor.OutputFormat);
//                                                    //bufferedWaveProvider.BufferDuration = TimeSpan.FromSeconds(maxBufferTime); // allow us to get well ahead of ourselves
//                                                    //convert = new Wave16ToFloatProvider(bufferedWaveProvider);
//                                                    //convert.Volume = _volume;
//                                                    //output = new NAudio.Wave.SampleProviders.SampleChannel(convert);

//                                                    // key moved
//                                                    //   my_uAudioPlayer2.fireOutSide = ReadData;

//                                                    // start the loop update
//                                                    if (sendStartLoopPump != null)
//                                                        sendStartLoopPump();
//                                                }
//                                                int decompressed = decompressor.DecompressFrame(frame, temp_buffer, 0);
//                                                bufferedWaveProvider.AddSamples(temp_buffer, 0, decompressed);
//#if uAudio_debug
//                                                UnityEngine.Debug.LogWarning(".");
//#endif
//                                            }
//                                            catch (System.Exception ex)
//                                            {
//                                                UnityEngine.Debug.LogException(new System.Exception("uAudio_Streaming - Start_OpenWebStream_Responce #87sgfv876fsdv78dsv"));
//                                                UnityEngine.Debug.LogException(ex);
//                                            }
//                                        }
//                                    }
//                                    else
//                                    {
//                                        //buff circularBuffer=new buff();
//                                        MemoryDel m = new MemoryDel();

//                                        byte[] buf = new byte[1024];


//                                        bool once = false;

//                                        reader = new NLayer.MpegFile(readFullyStream);

//                                        output = reader;
//                                        runPlay = true;

//                                        //while (playbackState != StreamingPlaybackState.Stopped)
//                                        //{
//                                        //    readFullyStream.Read(buf, 0, 1024);

//                                        //    m.Write(buf, 0, 1024);
//                                        //    if(!once&&m.Length> 1024 * 32)
//                                        //    {
//                                        //        once = true; 
//                                        //        reader = new NLayer.MpegFile(readFullyStream);

//                                        //        output = reader;
//                                        //        runPlay = true;
//                                        //    }
//                                        //}

//                                    }
//                                }
//                              //  while ( playbackState != StreamingPlaybackState.Stopped && !fullyDownloaded);
//                            }
//                        }
//                    }
//                    catch (System.Exception ex)
//                    {
//                        ShowError("error #vieronvoer " + ex.Message);
//                    }
//                }
//            }
//            catch (System.Exception ex)
//            {
//                ShowError("error #4h54h556h5 " + ex.Message);
//            }
//#if uAudio_debug
//            UnityEngine.Debug.LogWarning(System.Environment.NewLine + System.Environment.NewLine + "runPlay"+System.Environment.NewLine );
//#endif
//        }
//        public bool runPlay = false;
//        public void ReadData(float[] data)
//        {
//            if (output != null)
//            {
//                output.Read(data, 0, data.Length);
//            }
//        }
//#endregion ---webstream---

//#region func
//        public void ChangeCurrentTime(TimeSpan timeIN)
//        {
//            UnityEngine.Debug.LogException(new System.Exception("uAudio_Streaming - ChangeCurrentTime #8h0shd9v8hsd"));
//        }

//        public void LoadFile(string targetFile)
//        {
//            target_URL = targetFile;
//            my_uAudioPlayer2.SetFile(target_URL);
//        }

//        public void SetFile(string targetFile)
//        {
//            target_URL = targetFile;
//            my_uAudioPlayer2.SetFile(target_URL);
//        }
//        private bool IsBufferNearlyFull
//        {
//            get
//            {
//                return bufferedWaveProvider != null &&
//                       bufferedWaveProvider.BufferLength - bufferedWaveProvider.BufferedBytes
//                       < bufferedWaveProvider.WaveFormat.AverageBytesPerSecond / 4;
//            }
//        }

//        public string AudioTitle
//        {
//            get
//            {
//                return target_URL;
//            }
//        }

//        public PlayBackState PlaybackState
//        {
//            get
//            {
//                if (playbackState == StreamingPlaybackState.Playing)
//                    return PlayBackState.Playing;
//                else
//                    return PlayBackState.Paused;
//            }
//        }

//        public TimeSpan TotalTime
//        {
//            get
//            {
//                return TimeSpan.Zero;
//            }
//        }

//        public TimeSpan CurrentTime
//        {
//            get
//            {
//                return TimeSpan.Zero;
//            }

//            set
//            {
//                // throw new NotImplementedException();
//            }
//        }

//        public float Pan
//        {
//            get
//            {
//                ShowError("uAudio_Streaming - Pan #v87sfd76v6sd");
//                return 0;
//            }

//            set
//            {
//                ShowError("uAudio_Streaming - Pan #f6sa76cf76sac");
//            }
//        }

//        public Action PlayBackStopped
//        {
//            get
//            {
//                ShowError("uAudio_Streaming - PlayBackStopped #a7gfv876asvas");
//                return null;
//            }

//            set
//            {
//                ShowError("uAudio_Streaming - PlayBackStopped #97vasr8as8va");
//            }
//        }

//        public Action SLEEP
//        {
//            get
//            {
//                ShowError("SLEEP #h9dsvd");
//                throw new NotImplementedException();
//            }

//            set
//            {
//                ShowError("SLEEP #h9dsvd");
//                throw new NotImplementedException();
//            }
//        }

//        private static IMp3FrameDecompressor CreateFrameDecompressor(Mp3Frame frame)
//        {
//            WaveFormat waveFormat = new Mp3WaveFormat(frame.SampleRate, frame.ChannelMode == ChannelMode.Mono ? 1 : 2,
//                frame.FrameLength, frame.BitRate);
//            return new AcmMp3FrameDecompressor(waveFormat);
//        }
//#endregion ---func---

//#region GUI
//        private void buttonPause_Click(object sender, EventArgs e)
//        {
//            if (playbackState == StreamingPlaybackState.Playing || playbackState == StreamingPlaybackState.Buffering)
//            {
//                Pause();
//            }
//        }

//        private void ShowBufferState(double totalSeconds)
//        {
//            //            labelBuffered.Text = String.Format("{0:0.0}s", totalSeconds);
//            //            progressBarBuffer.Value = (int)(totalSeconds * 1000);
//        }
//#endregion ---GUI---

//#region loop
//        private void OnPlaybackStopped(object sender, StoppedEventArgs e)
//        {
//            ShowError("uAudio_Streaming - OnPlaybackStopped #c7asdc765adscas");
//        }
//     public double BufferedTime
//        {
//            get
//            {
//                if(bufferedWaveProvider!= null)
//                //if(bufferedWaveProvider.BufferedDuration != null)
//                return bufferedWaveProvider.BufferedDuration.TotalSeconds;

//                return 0;
//            }
//        }

//        public void callPlay()
//        {
//#if uAudio_debug
//            UnityEngine.Debug.Log(System.Environment.NewLine + "--------------" + System.Environment.NewLine);
//            UnityEngine.Debug.Log(System.Environment.NewLine + "Play" + System.Environment.NewLine);
//            UnityEngine.Debug.Log(System.Environment.NewLine + "--------------" + System.Environment.NewLine);
//#endif
//            my_uAudioPlayer2.Play();
//        }
//        bool targetWindows = false;
//        System.Collections.IEnumerator UpdateLoop()
//        {
//            while (!runPlay)
//            {

//                yield return new UnityEngine.WaitForSeconds(.1f);

//            }
//            if (runPlay)
//            {
//                //runPlay = false;
//                callPlay();
//            }
//            //Play();
//            if (sendPlaying != null)
//                sendPlaying();
//#if uAudio_debug
//            UnityEngine.Debug.Log(System.Environment.NewLine+"Start read Loop:"+ System.Environment.NewLine );
//#endif
//            do
//            {
//                try
//                {
//                    if (playbackState != StreamingPlaybackState.Stopped && playbackState != StreamingPlaybackState.Paused)
//                    {

//                        if (!targetWindows || bufferedWaveProvider != null)
//                        {
//                            if (targetWindows)
//                            {
//                                double bufferedSeconds;
//                                bufferedSeconds = bufferedWaveProvider.BufferedDuration.TotalSeconds;
//                                ShowBufferState(bufferedSeconds);
//                                if (bufferedSeconds < minBufferTime)
//                                {
//                                    continue;
//                                    // buffering
//#if uAudio_debug
//                                    UnityEngine.Debug.Log(System.Environment.NewLine + "buffer: ^. ");
//#endif
//                                }
//                                if (fullyDownloaded && bufferedSeconds == 0)
//                                {
//                                    try
//                                    {
//#if uAudio_debug
//                                        UnityEngine.Debug.Log(System.Environment.NewLine + "over: ^q ");
//#endif
//                                        playbackState = StreamingPlaybackState.Stopped;
//                                        halt();
//                                    }
//                                    catch
//                                    {
//                                        ShowError("uAudio_Streaming - UpdateLoop #sa86cras76rca");
//                                    }
//                                }
//                            }

//                            // make it stutter less if we buffer up a decent amount before playing
////                            if (playbackState == StreamingPlaybackState.Buffering)//&& bufferedSeconds > 4 )
////                            {
////#if uAudio_debug
////                                UnityEngine.Debug.LogWarning("&a&");
////#endif
////                                ShowError("tic-Play");
////                                playbackState = StreamingPlaybackState.Paused;
////                                Play();
////                            }
//                        }
//                        else
//                        {
//#if uAudio_debug
//                            //System.Threading.Thread.Sleep(1000);
//                            if (responceStream == null)
//                            {
//                                UnityEngine.Debug.Log(System.Environment.NewLine + "no buffer provider: ^webReply ");

//                            }
//                            else

//                                UnityEngine.Debug.Log(System.Environment.NewLine + "no buffer provider: ^xx ");
//#endif
//                        }
//                    }
//                }
//                catch
//                {
//                    ShowError("#34c3434");
//                }
//                yield return new UnityEngine.WaitForSeconds(.1f);
//            }
//            while (targetWindows && playbackState != StreamingPlaybackState.Stopped);
//#if uAudio_debug
//            UnityEngine.Debug.Log(System.Environment.NewLine + "end read loop: ^.x ");
//#endif
//            //sendStopLoopPump();
//        }
//#endregion ---loop---

//#region thread stuff
//        //void CallUnityThread()
//        //{
//        //    ThreadPump.MainThreadPump.AddFunction_Unity(_CallUnityThread_fire());
//        //}
//        //System.Collections.IEnumerator _CallUnityThread_fire()
//        //{
//        //    if (sendUpdate != null)
//        //        sendUpdate();
//        //    yield return null;
//        //}
//#endregion ---thread stuff---

//#region Dispose
//        bool DisposedDone = false;
//        public void Dispose()
//        {
//            try
//            {
//                if (!DisposedDone)
//                {
//                    DisposedDone = true;
//                    try
//                    {
//                        halt();
//                    }
//                    catch
//                    {
//                        ShowError("#grtr6556j56j");
//                    }
//                    sendPlaying = null;

//                    if (webRequest != null)
//                    {
//                        try
//                        {
//                            webRequest.Abort();
//                            webRequest = null;
//                        }
//                        catch
//                        {
//                            ShowError("Dispose - #8f6sd87fsdf");
//                        }
//                    }

//                    if (responceStream != null)
//                    {
//                        try
//                        {
//                            responceStream.Close();
//                            responceStream = null;
//                        }
//                        catch
//                        {
//                            ShowError("Dispose - #8f6sd87fsdf");
//                        }
//                    }
//                    if (responce != null)
//                    {
//                        try
//                        {
//                            responce.Close();
//                            responce = null;
//                        }
//                        catch
//                        {
//                            ShowError("Dispose - #8f6sd87fsdf");
//                        }
//                    }
//                    if (webReply != null)
//                    {
//                        try
//                        {
//                            webReply.Abort();
//                            webReply = null;
//                        }
//                        catch
//                        {
//                            ShowError("Dispose - #8f6sd87fsdf");
//                        }
//                    }
//                    Disposed = null;

//                    sendStartLoopPump = null;
//                    sendStopLoopPump = null;

//                    if (Disposed != null)
//                    {
//                        Disposed(this, new EventArgs());
//                        Disposed = null;
//                    }
//                }
//            }
//            catch
//            {
//                ShowError("#xcw2434");
//                error = true;
//            }
//        }
//#endregion ---Dispose---
//    }
//}
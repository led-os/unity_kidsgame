﻿using System;
using NAudio.Wave;

namespace NLayer
{
    public class MpegFile : IDisposable, NAudio.Wave.ISampleProvider
    {
        float[] _readBuf = new float[1152 * 2];
        int _readBufLen, _readBufOfs;


        public int Read(float[] buffer, int offset, int count)
        {
            return ReadSamples(buffer, offset, count);
        }

        public WaveFormat WaveFormat
        {
            get
            {
                return new WaveFormat(SampleRate, Channels);
            }
        }

        System.IO.Stream _stream;
        bool _closeStream, _eofFound;

        Decoder.MpegStreamReader _reader;
        MpegFrameDecoder _decoder;

        object _seekLock = new object();
        long _position;

        //public MpegFile(string fileName)
        //{
        //    Init(System.IO.File.Open(fileName, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.Read), true);
        //}

        public MpegFile(System.IO.Stream stream, bool canSeek = false)
        {
            Init(stream, true, canSeek);
        }

        void Init(System.IO.Stream stream, bool closeStream, bool canSeek = false)
        {
            _stream = stream;
            _closeStream = closeStream;

            _reader = new Decoder.MpegStreamReader(_stream, canSeek);

            _decoder = new MpegFrameDecoder();
        }

        public void Dispose()
        {
            if (_closeStream)
            {
                //_stream..Close();
                _closeStream = false;
            }
        }

        public int SampleRate { get {
                return _reader.SampleRate; } }
        public int Channels { get {
                return _reader.Channels; } }

        public long Length
        {
            get
            {
                return _reader.SampleCount * _reader.Channels * sizeof(float);
            }
        }

        public TimeSpan Duration
        {
            get
            {
                var len = _reader.SampleCount;
                if (len == -1) return TimeSpan.Zero;
                return TimeSpan.FromSeconds((double)len / _reader.SampleRate);
            }
        }

        public void SetEQ(float[] eq)
        {
            _decoder.SetEQ(eq);
        }

        public StereoMode StereoMode
        {
            get { return _decoder.StereoMode; }
            set { _decoder.StereoMode = value; }
        }

        public int ReadSamples(byte[] buffer, int index, int count)
        {
            if (index < 0 || index + count > buffer.Length) throw new ArgumentOutOfRangeException("index");

            // make sure we're asking for an even number of samples
            count -= (count % sizeof(float));

            return ReadSamplesImpl(buffer, index, count);
        }

        public int ReadSamples(float[] buffer, int index, int count)
        {
            if (index < 0 || index + count > buffer.Length) throw new ArgumentOutOfRangeException("index");

            // ReadSampleImpl "thinks" in bytes, so adjust accordingly
            return ReadSamplesImpl(buffer, index * sizeof(float), count * sizeof(float)) / sizeof(float);
        }

        int ReadSamplesImpl(Array buffer, int index, int count)
        {
            var cnt = 0;

            // lock around the entire read operation so seeking doesn't bork our buffers as we decode
            //lock (_seekLock)
            {
                while (count > 0)
                {
                    if (_readBufLen > _readBufOfs)
                    {
                        // we have bytes in the buffer, so copy them first
                        var temp = _readBufLen - _readBufOfs;
                        if (temp > count) temp = count;
                        Buffer.BlockCopy(_readBuf, _readBufOfs, buffer, index, temp);

                        // now update our counters...
                        cnt += temp;

                        count -= temp;
                        index += temp;

                        _position += temp;
                        _readBufOfs += temp;

                        // finally, mark the buffer as empty if we've read everything in it
                        if (_readBufOfs == _readBufLen)
                        {
                            _readBufLen = 0;
                        }
                    }

                    // if the buffer is empty, try to fill it
                    //  NB: If we've already satisfied the read request, we'll still try to fill the buffer.
                    //      This ensures there's data in the pipe on the next call
                    if (_readBufLen == 0)
                    {
                        if (_eofFound)
                        {
                            break;
                        }

                        // decode the next frame (update _readBufXXX)
                        var frame = _reader.NextFrame();
                        if (frame == null)
                        {
                            _eofFound = true;
                            break;
                        }

                        try
                        {
                            _readBufLen = _decoder.DecodeFrame(frame, _readBuf, 0) * sizeof(float);
                            _readBufOfs = 0;
                        }
                        catch (System.IO.EndOfStreamException)
                        {
                            // no more frames
                            _eofFound = true;
                            break;
                        }
                        catch (System.IO.IOException)
                        {
                            // bad frame...  try again...
                            _decoder.Reset();
                            _readBufOfs = _readBufLen = 0;
                            continue;
                        }

                        finally
                        {
                            frame.ClearBuffer();
                        }
                    }
                }
            }
            return cnt;
        }

    }
}
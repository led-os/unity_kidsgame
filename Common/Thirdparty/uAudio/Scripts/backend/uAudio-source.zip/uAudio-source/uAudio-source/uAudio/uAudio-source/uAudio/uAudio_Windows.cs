﻿using UnityEngine;
using System;
namespace uAudio.uAudio_backend
{
    public class uAudio_Windows : uAudio_backend.IAudioPlayer, System.IDisposable
    {
        #region vars
        Action<PlayBackState> _sendPlaybackState;
        public Action<PlayBackState> sendPlaybackState
        {
            get
            {
                return _sendPlaybackState;
            }

            set
            {
                _sendPlaybackState = value;
            }
        }
        public uAudio_backend.AudioPlayback audioPlayback;
        public string AudioTitle { get { return System.IO.Path.GetFileNameWithoutExtension(targetFile); } }
        string targetFile;

        public float Pan
        {
            get
            {
                return 0;
            }
            set
            {
            }
        }
        string uAudio_backend.IAudioPlayer.current_TargetFile_Loaded
        {
            get
            { return targetFile; }
        }
        public void ChangeCurrentTime(System.TimeSpan timeIN)
        {
            CurrentTime = timeIN;
        }

        public System.TimeSpan CurrentTime
        {
            get
            {
                if (audioPlayback != null
                && audioPlayback.inputStream != null)
                    return audioPlayback.inputStream.CurrentTime;
                else
                    return System.TimeSpan.Zero;
            }
            set
            {
                if (audioPlayback != null && audioPlayback.inputStream != null)
                    audioPlayback.inputStream.CurrentTime = value;
            }
        }

        public PlayBackState PlaybackState
        {
            get
            {
                return (PlayBackState)audioPlayback.playbackDevice.PlaybackState;
            }
        }
        float _volume = 1;
        public float Volume
        {
            get
            {
                if (audioPlayback != null)
                    return audioPlayback.Volume;
                else
                    return _volume;
            }
            set
            {
                if (audioPlayback != null)
                    audioPlayback.Volume = value;
                _volume = value;
            }
        }
        public int SongLength { get { return (int) audioPlayback.inputStream.length; } }

        public System.TimeSpan TotalTime
        {
            get
            {
                if (audioPlayback != null && audioPlayback.inputStream != null)
                    return audioPlayback.inputStream.TotalTime;
                else
                    return System.TimeSpan.Zero;
            }
        }

  
        #endregion vars

        #region con
        public uAudio_Windows(uAudio_backend.IAudioPlayer HostIN)
        {
            audioPlayback = new uAudio_backend.AudioPlayback();
            audioPlayback.Volume = _volume;

            sendPlaybackState = audioPlayback.sendPlaybackState;
        }

        public void LoadFile(string targetFileIN)
        {
            targetFile = targetFileIN;
            audioPlayback.Load(targetFile);
        }
        #endregion ---con---

        #region funcs
        public void SetFile(string targetFileIN)
        {
            targetFile = targetFileIN;
        }

        public void Pause()
        {
            audioPlayback.Pause();
            if (sendPlaybackState != null)
                sendPlaybackState(PlayBackState.Paused);

        }

        public void Play(System.TimeSpan? OffsetStart=null)
        {
            audioPlayback.Play(OffsetStart);
        }

        public void Stop()
        {
            audioPlayback.Stop();

        }

        //public static void Init(NAudio.Wave.IWavePlayer wavePlayer, NAudio.Wave.ISampleProvider sampleProvider, bool convertTo16Bit = false)
        //{
        //    NAudio.Wave.IWaveProvider provider = convertTo16Bit ? (NAudio.Wave.IWaveProvider)new NAudio.Wave.SampleProviders.SampleToWaveProvider16(sampleProvider) : new NAudio.Wave.SampleProviders.SampleToWaveProvider(sampleProvider);
        //    wavePlayer.Init(provider);
        //}
        #endregion funcs

        #region Dispose
        void OnApplicationQuit()
        {
            Dispose();
        }
        bool isDisposed = false;
        public void Dispose()
        {
            if (isDisposed)
                return;
            else
                isDisposed = true;

            try
            {
                if (audioPlayback != null)
                {
                    audioPlayback.Stop();
                    audioPlayback.Dispose();
                }

                //    if (_mainOutputStream != null)
                //    {
                //        _mainOutputStream.Close();
                ////        _mainOutputStream.Dispose();
                //        _mainOutputStream = null;
                //    }
                targetFile = string.Empty;
                audioPlayback = null;

                _sendPlaybackState = null;
            }
            catch (System.Exception ex)
            {
                Debug.LogException(ex);
                throw ex;
            }
        }
        #endregion --Dispose---

        private void ShowError(string message)
        {
            UnityEngine.Debug.Log("AudioStreaming #tbrb54 ---" + message);
        }

        Action uAudio_backend.IAudioPlayer.SLEEP
        {
            get
            {
                UnityEngine.Debug.LogWarning("SLEEP #h9dsvd");
                throw new NotImplementedException();
            }

            set
            {
                UnityEngine.Debug.LogWarning("SLEEP #h9dsvd");
                throw new NotImplementedException();
            }
        }
    }
}
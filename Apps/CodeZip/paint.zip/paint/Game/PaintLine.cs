﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using Vectrosity;

public class PaintLine : UIView
{
    UITouchEvent uiTouchEvent;
    VectorLine lineCur;
    List<Vector3> listPointCur;
    float lineWidth = 2f;
    BoxCollider boxCollider;
    public Rect rectMain;
    /// <summary>
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    void Awake()
    {
        boxCollider = this.gameObject.AddComponent<BoxCollider>();
        uiTouchEvent = this.gameObject.AddComponent<UITouchEvent>();
        uiTouchEvent.callBackTouch = OnUITouchEvent;
        VectorLine.SetCamera3D(mainCam);
    }

    // Use this for initialization
    void Start()
    {


    }

    // Update is called once per frame
    void Update()
    {

    }

    public void UpdateRect(Rect rc)
    {
        if (boxCollider != null)
        {
            boxCollider.size = new Vector3(rc.width, rc.height);
        }
    }

    void CreateLine()
    {

        listPointCur = new List<Vector3>();
        // listPointCur.Add(Vector3.zero);
        // listPointCur.Add(new Vector3(5, 0, 0));

        lineCur = new VectorLine("line", listPointCur, lineWidth);
        lineCur.lineType = LineType.Continuous;
        //圆滑填充画线
        lineCur.joins = Joins.Fill;

        lineCur.color = Color.red;
        lineCur.Draw3D();
        GameObject objLine = lineCur.GetObj();
        objLine.transform.parent = this.gameObject.transform;
        objLine.transform.localPosition = Vector3.zero;
    }
    public void OnUITouchEvent(UITouchEvent ev, PointerEventData eventData, int status)
    {
        switch (status)
        {
            case UITouchEvent.STATUS_TOUCH_DOWN:
                onTouchDown();
                break;
            case UITouchEvent.STATUS_TOUCH_MOVE:
                onTouchMove();
                break;
            case UITouchEvent.STATUS_TOUCH_UP:
                onTouchUp();
                break;
        }
    }
    Vector3 GetTouchLocalPosition()
    {
        Vector2 inputPos = Common.GetInputPosition();
        Vector3 posTouchWorld = mainCam.ScreenToWorldPoint(inputPos);
        Vector3 loaclPos = this.transform.InverseTransformPoint(posTouchWorld);
        loaclPos.z = 0;
        return loaclPos;
    }
    void onTouchDown()

    {
        CreateLine();
        Vector3 pos = GetTouchLocalPosition();
        listPointCur.Add(pos);
        lineCur.Draw3D();
    }
    void onTouchMove()
    {
        Vector3 pos = GetTouchLocalPosition();
        listPointCur.Add(pos);
        lineCur.Draw3D();

    }
    void onTouchUp()
    {
        Vector3 pos = GetTouchLocalPosition();
        listPointCur.Add(pos);
        lineCur.Draw3D();
    }

}

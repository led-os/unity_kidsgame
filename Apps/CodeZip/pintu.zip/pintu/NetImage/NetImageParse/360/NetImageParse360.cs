﻿
using UnityEngine;
using System.Collections;
using Tacticsoft;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Text;
using LitJson;
//360 图片API
//https://blog.csdn.net/qq_41113081/article/details/87551942
 
public class NetImageParse360:NetImageParseBase
{
 
    HttpRequest httpSortList;
    HttpRequest httpImageList;
 
    public void StartParseSortList()
    {
        httpSortList = new HttpRequest(OnHttpRequestFinished);
        httpSortList.Get("https://itunes.apple.com/lookup?id=914391781");
    }

    public void StartParseImageList(ItemInfo info)
    {
        httpImageList = new HttpRequest(OnHttpRequestFinished);
        httpImageList.Get("https://itunes.apple.com/lookup?id=914391781");
    }

    public void ParseSortList(byte[] data)
    {
        string str = Encoding.UTF8.GetString(data);
        Debug.Log(str);
        JsonData jsonRoot = JsonMapper.ToObject(str);
        JsonData jsonResult = jsonRoot["results"];
        //Debug.Log("Appversion ParseAppstore 1");
        JsonData jsonItem = jsonResult[0];
        string url = (string)jsonItem["trackViewUrl"];

        
    }

    public void ParseImageList(byte[] data)
    {
       
    }

    public void OnHttpRequestFinished(HttpRequest req, bool isSuccess, byte[] data)
    {
        Debug.Log("Appversion OnHttpRequestFinished:isSuccess=" + isSuccess);
        if (httpSortList == req)
        {
            if (isSuccess)
            {
                ParseSortList(data);
            }
            else
            {
               
            }

        }
        if (httpImageList == req)
        {
            if (isSuccess)
            {
                ParseImageList(data);
            }
            else
            {
              
            }
        }



    }

}


﻿
using UnityEngine;
using System.Collections;
using Tacticsoft;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Text;
using LitJson; 
public class NetImageParseBase
{
  

    public void StartParseSortList()
    {
       
    }

    public void StartParseImageList(ItemInfo info)
    {
      
    }

    public void ParseSortList(byte[] data)
    {
        string str = Encoding.UTF8.GetString(data);
        Debug.Log(str);
        JsonData jsonRoot = JsonMapper.ToObject(str);
        JsonData jsonResult = jsonRoot["results"];
        //Debug.Log("Appversion ParseAppstore 1");
        JsonData jsonItem = jsonResult[0];
        string url = (string)jsonItem["trackViewUrl"];

        
    }

    public void ParseImageList(byte[] data)
    {
         
    }

    public void OnHttpRequestFinished(HttpRequest req, bool isSuccess, byte[] data)
    {
        Debug.Log("Appversion OnHttpRequestFinished:isSuccess=" + isSuccess);
        
    }

}


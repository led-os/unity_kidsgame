﻿using System.Collections;
using System.Collections.Generic;
using Moonma.SysImageLib;
using UnityEngine;
using UnityEngine.UI;

public class UINetImageList : UIView
{
    public GameObject objLayoutBtn;
    public Button btnPlay; 
    public Button btnNetImage;
    void Awake()
    {
       
    }

    // Use this for initialization
    void Start()
    {
        LayOut();
        OnUIDidFinish();
    }

    // Update is called once per frame
    void Update()
    {
       
    }

    public void OnClickBtnPlay()
    {
        
    }
 
    public override void LayOut()
    {
       
    }
 
}

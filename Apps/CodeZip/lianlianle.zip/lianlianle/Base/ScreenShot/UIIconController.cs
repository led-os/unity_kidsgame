﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UIIconController : UIShotBase
{
    public UIImage imageBg;
    public UIImage imageHD;
    public UIImage imageBoard;
    public UIImage imageHuman;

    public UIImage imageItem0;
    public UIImage imageItem1;
    public UIImage imageItem2;
    public UIImage imageItem3;
    List<object> listItem;
    /// <summary>
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    void Awake()
    {
        imageHD.gameObject.SetActive(false);
        imageBoard.gameObject.SetActive(true);
        string pic_name = Common.GAME_DATA_DIR + "/screenshot/icon/bg";
        string pic = pic_name + ".jpg";
        if (!FileUtil.FileIsExistAsset(pic))
        {
            pic = pic_name + ".png";
        }
        imageBg.UpdateImage(pic);
        if (imageHuman != null)
        {
            imageHuman.UpdateImage(Common.GAME_DATA_DIR + "/screenshot/icon/human.png");
        }

        listItem = LevelManager.main.GetGuankaListOfAllPlace();

        LayOut();
    }
    void Start()
    {
        IconViewController iconctroller = (IconViewController)this.controller;
        if (iconctroller != null)
        {
            if (iconctroller.deviceInfo.isIconHd)
            {
                imageHD.gameObject.SetActive(true);
            }

        }

        Shader shaderColor = Shader.Find("Custom/ShapeColor");
        {
            LianLianLeItemInfo info = listItem[0] as LianLianLeItemInfo;
            LianLianLeItemInfo infoPic = info.listPic0[0] as LianLianLeItemInfo;
            imageItem0.UpdateImage(infoPic.pic);
            Material mat = new Material(shaderColor);
            mat.SetColor("_ColorShape", Color.red);
            imageItem0.image.material = mat;
        }
        {
            LianLianLeItemInfo info = listItem[1] as LianLianLeItemInfo;
            LianLianLeItemInfo infoPic = info.listPic0[0] as LianLianLeItemInfo;
            imageItem1.UpdateImage(infoPic.pic);

        }


        {
            LianLianLeItemInfo info = listItem[1] as LianLianLeItemInfo;
            LianLianLeItemInfo infoPic = info.listPic0[0] as LianLianLeItemInfo;
            imageItem2.UpdateImage(infoPic.pic);
            Material mat = new Material(shaderColor);
            mat.SetColor("_ColorShape", Color.red);
            imageItem2.image.material = mat;
        }
        {
            LianLianLeItemInfo info = listItem[0] as LianLianLeItemInfo;
            LianLianLeItemInfo infoPic = info.listPic0[0] as LianLianLeItemInfo;
            imageItem3.UpdateImage(infoPic.pic);

        }
        LayOut();
        OnUIDidFinish();
    }


    public override void LayOut()
    {
        base.LayOut();

    }
}

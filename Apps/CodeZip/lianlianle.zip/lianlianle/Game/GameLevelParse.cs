﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.UI;

public class GameLevelParse : LevelParseBase
{


    List<object> listBg;


    public string keyGameGuide;
    AutoMakeGuanka autoMakeGuanka;
    public List<object> listAutoGuanka;//item index list
    static private GameLevelParse _main = null;
    public static GameLevelParse main
    {
        get
        {
            if (_main == null)
            {
                _main = new GameLevelParse();
            }
            return _main;
        }
    }




    public LianLianLeItemInfo GetItemInfo()
    {
        int idx = LevelManager.main.gameLevel;
        if (listGuanka == null)
        {
            return null;
        }
        if (idx >= listGuanka.Count)
        {
            return null;
        }
        LianLianLeItemInfo info = listGuanka[idx] as LianLianLeItemInfo;
        return info;
    }



    public override int GetGuankaTotal()
    {
        int count = ParseGuanka();
        return count;
    }

    public override void CleanGuankaList()
    {
        if (listGuanka != null)
        {
            listGuanka.Clear();
        }

    }
    public override int ParseGuanka()
    {
        ParseBgList();
        ParseGuankaJson();
        int count = listGuanka.Count;
        return count;

    }

    void ParseBgList()
    {
        if ((listBg != null) && (listBg.Count != 0))
        {
            return;
        }
        listBg = new List<object>();
        string fileName = Common.GAME_RES_DIR + "/image/bg/bg.json";
        //FILE_PATH
        string json = FileUtil.ReadStringAsset(fileName);//((TextAsset)Resources.Load(fileName, typeof(TextAsset))).text;
        JsonData root = JsonMapper.ToObject(json);
        JsonData items = root["list"];
        for (int i = 0; i < items.Count; i++)
        {
            LianLianLeItemInfo info = new LianLianLeItemInfo();
            JsonData item = items[i];
            string strdir = Common.GAME_RES_DIR + "/image/bg";
            info.pic = strdir + "/" + (string)item["pic"];
            info.listColorFilter = new List<object>();
            JsonData colorFilter = item["color_filter"];
            for (int j = 0; j < colorFilter.Count; j++)
            {
                JsonData itemtmp = colorFilter[j];
                LianLianLeItemInfo infotmp = new LianLianLeItemInfo();
                infotmp.id = (string)itemtmp["color_id"];
                info.listColorFilter.Add(infotmp);

            }
            listBg.Add(info);
        }
    }

    void AddItemImage(List<object> list, ItemInfo infoId, bool enable_color)
    {
        ItemInfo infoPlace = LevelManager.main.GetPlaceItemInfo(LevelManager.main.placeLevel);
        LianLianLeItemInfo infopic = new LianLianLeItemInfo();
        infopic.id = infoId.id;
        infopic.pic = infoId.pic;
        infopic.category = infoPlace.id;
        infopic.isColor = false;

        //随机打乱
        int rdm = Random.Range(0, list.Count + 1);

        if (enable_color)
        {
            int rdm_tmp = Random.Range(0, 2);
            bool is_up = (rdm_tmp == 0) ? true : false;
            if (rdm > list.Count / 2)
            {
                infopic.isColor = is_up;
            }
            else
            {
                infopic.isColor = !is_up;
            }
        }
        list.Insert(rdm, infopic);
    }

    void ParseAutoGuanka()
    {
        if (autoMakeGuanka == null)
        {
            // autoMakeGuanka = this.gameObject.AddComponent<AutoMakeGuanka>();
            autoMakeGuanka = new AutoMakeGuanka();
            autoMakeGuanka.Init();
            listAutoGuanka = autoMakeGuanka.ParseAutoGuankaJson();
        }

        ItemInfo infoPlace = LevelManager.main.GetPlaceItemInfo(LevelManager.main.placeLevel);
        keyGameGuide = "STR_GAME_GUIDE_" + infoPlace.id;
        ParseGuankaItemId(GUANKA_ITEM_NUM_ONE_GROUP);
        int group = listGuankaItemId.Count / GUANKA_ITEM_NUM_ONE_GROUP;
        int idx = 0;
        int count = listAutoGuanka.Count;
        for (int g = 0; g < group; g++)
        {

            for (int i = 0; i < count; i++)
            {
                LianLianLeItemInfo infoAutoGuanka = listAutoGuanka[i] as LianLianLeItemInfo;
                string strcontent = infoAutoGuanka.id;
                string[] strArray = strcontent.Split(',');

                LianLianLeItemInfo info = new LianLianLeItemInfo();
                info.listPic0 = new List<object>();
                info.listPic1 = new List<object>();
                string strDirPic = Common.GAME_RES_DIR + "/image/" + infoPlace.id;
                //pics0 
                int pos_index = 0;
                idx = 0;
                foreach (string stritem in strArray)
                {
                    idx = Common.String2Int(stritem) + g * GUANKA_ITEM_NUM_ONE_GROUP;
                    ItemInfo infoId = listGuankaItemId[idx] as ItemInfo;
                    int rdm = Random.Range(0, 2);
                    bool enable_color = (rdm == 0) ? true : false;
                    AddItemImage(info.listPic0, infoId, enable_color);
                    AddItemImage(info.listPic1, infoId, !enable_color);

                    pos_index++;
                }




                listGuanka.Add(info);
            }

        }

    }
    void ParseGuankaJson()
    {
        if ((listGuanka != null) && (listGuanka.Count != 0))
        {
            return;
        }

        listGuanka = new List<object>();
        int idx = LevelManager.main.placeLevel;
        ItemInfo infoPlace = LevelManager.main.GetPlaceItemInfo(LevelManager.main.placeLevel);
        string fileName = Common.GAME_RES_DIR + "/guanka/item_" + infoPlace.id + ".json";
        // if (idx > 5)
        {
            ParseAutoGuanka();
            return;
        }
        //FILE_PATH
        string json = FileUtil.ReadStringAsset(fileName);//((TextAsset)Resources.Load(fileName, typeof(TextAsset))).text;
                                                         // Debug.Log("json::"+json);
        JsonData root = JsonMapper.ToObject(json);
        JsonData items = root["items"];

        keyGameGuide = "STR_PLACE_" + infoPlace.id + "_GUANKA" + LevelManager.main.gameLevel;
        for (int i = 0; i < items.Count; i++)
        {
            LianLianLeItemInfo info = new LianLianLeItemInfo();
            JsonData item = items[i];
            info.listPic0 = new List<object>();
            info.listPic1 = new List<object>();
            string strDirPic = Common.GAME_RES_DIR + "/image/" + infoPlace.id;
            JsonData jsonPic0 = item["pics0"];
            foreach (JsonData item_pic in jsonPic0)
            {
                LianLianLeItemInfo infopic = new LianLianLeItemInfo();
                infopic.pic = strDirPic + "/" + (string)item_pic["name"];
                infopic.category = (string)item_pic["type"];
                //随机打乱
                int rdm = Random.Range(0, info.listPic0.Count + 1);
                info.listPic0.Insert(rdm, infopic);
                if (Common.BlankString(info.pic))
                {
                    info.pic = infopic.pic;
                }

            }


            JsonData jsonPic1 = item["pics1"];
            foreach (JsonData item_pic in jsonPic1)
            {
                LianLianLeItemInfo infopic = new LianLianLeItemInfo();
                infopic.pic = strDirPic + "/" + (string)item_pic["name"];
                infopic.category = (string)item_pic["type"];
                //随机打乱
                int rdm = Random.Range(0, info.listPic1.Count + 1);
                info.listPic1.Insert(rdm, infopic);
            }


            listGuanka.Add(info);
        }

    }







}

﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class LianLianLeItemInfo : ItemInfo
{
    public string colorid;
    public List<object> listPic0;
    public List<object> listPic1;
    public List<object> listColorFilter;
    public Vector3 posNormalWorld;
    public int count;
    public bool isColor;
    public Color color;
}

public class UIGameLianLianLe : UIGameBase, IGameDelegate
{

    public GameObject objTopBar;
    public Text textTitle;
    public Image imageBar;



    List<object> listColorShow;
    List<object> listItem;
    bool isItemHasSel;
    Vector2 ptDownScreen;
    Vector3 posItemWorld;
    LianLianLeItemInfo itemInfoSel;
    float heightImageBarNormal;

    GameLianLianLe gameLianLianLePrefab;
    GameLianLianLe gameLianLianLe;

    void Awake()
    {
        LoadPrefab();
        InitLanguage();
        GameGuankaParse.main.ParseGuanka();

    }


    // Use this for initialization
    void Start()
    {
        UpdateGuankaLevel(LevelManager.main.gameLevel);

    }

    // Update is called once per frame 
    void Update()
    {

        if (Input.GetKeyUp(KeyCode.Escape))
        {
            OnClickBtnBack();
        }
    }

    void LoadPrefab()
    {
        {
            GameObject obj = (GameObject)Resources.Load("AppCommon/Prefab/Game/GameLianLianLe");
            if (obj != null)
            {
                gameLianLianLePrefab = obj.GetComponent<GameLianLianLe>();

            }

        }

    }
    public override void UpdateGuankaLevel(int level)
    {
        base.UpdateGuankaLevel(level);

        AppSceneBase.main.ClearMainWorld();
        {
            gameLianLianLe = (GameLianLianLe)GameObject.Instantiate(gameLianLianLePrefab);
            AppSceneBase.main.AddObjToMainWorld(gameLianLianLe.gameObject);
            UIViewController.ClonePrefabRectTransform(gameLianLianLePrefab.gameObject, gameLianLianLe.gameObject);
            gameLianLianLe.transform.localPosition = new Vector3(0f, 0f, -1f);

        }
        LoadGame();
        //必须在LoadGame之后执行 
        LoadBg();

        UpdateTitle();

        LayOut();

        ShowUserGuide();
        Invoke("OnUIDidFinish", 2f);
    }

    static public void InitLanguage()
    {
        if (languageGame != null)
        {
            languageGame.SetLanguage(Language.main.GetLanguage());
            return;
        }
        languageGame = new Language();
        languageGame.Init(Common.GAME_RES_DIR + "/language/language.csv");
        languageGame.SetLanguage(Language.main.GetLanguage());
    }



    public override void LayOut()
    {

    }
    void UpdateTitle()
    {
        string str = StringOfItem(GameGuankaParse.main.GetItemInfo());
        textTitle.text = str;
        RectTransform rctranTopbar = objTopBar.transform as RectTransform;

        int fontsize = textTitle.fontSize;
        int str_w = (int)Common.GetStringLength(str, AppString.STR_FONT_NAME, fontsize);

        int disp_w = (int)rctranTopbar.rect.width;
        int str_line = str_w / disp_w;
        if ((str_w % disp_w) != 0)
        {
            str_line++;
        }

        RectTransform rctran = imageBar.transform as RectTransform;

        Vector2 sizeDelta = rctran.sizeDelta;
        float oft = 0;
        sizeDelta.x = str_w + fontsize + oft * 2;
        if (sizeDelta.x > disp_w)
        {
            sizeDelta.x = disp_w;
        }
        sizeDelta.y = heightImageBarNormal;
        if (str_line > 2)
        {
            sizeDelta.y = heightImageBarNormal * str_line / 2;
        }

        rctran.sizeDelta = sizeDelta;


        RectTransform rctranTitle = textTitle.transform as RectTransform;
        Vector2 sizeDeltaTitle = rctranTitle.sizeDelta;
        sizeDeltaTitle.y = sizeDelta.y;
        rctranTitle.sizeDelta = sizeDeltaTitle;

        TTS.main.Speak(str);
    }
    bool IsInColorFilter(LianLianLeItemInfo colorfilter, LianLianLeItemInfo info)
    {
        bool isfilter = false;
        foreach (LianLianLeItemInfo infocolor in colorfilter.listColorFilter)
        {
            if (info.id == infocolor.id)
            {
                isfilter = true;
                break;
            }
        }
        return isfilter;
    }

    void LoadBg()
    {
        AppSceneBase.main.UpdateWorldBg(AppRes.IMAGE_GAME_BG);
    }


    string StringOfItem(LianLianLeItemInfo info)
    {

        ItemInfo infoplace = LevelManager.main.GetPlaceItemInfo(LevelManager.main.placeLevel);
        //STR_PLACE_LIVINGROOM_GUANKA0
        string key = GameGuankaParse.main.keyGameGuide;//infoplace.title + "_GUANKA" + GameManager.gameLevel;
        Debug.Log("key=" + key);
        if (Common.BlankString(key))
        {
            return "";
        }
        if (languageGame == null)
        {
            return "";
        }

        string str = languageGame.GetString(key);

        return str;
    }
    void PlayAudioItem(AudioClip audioclip)
    {
        //AudioPlayer对象在场景切换后可能从当前scene移除了
        GameObject audioPlayer = GameObject.Find("AudioPlayer");
        if (audioPlayer != null)
        {
            AudioSource audioSource = audioPlayer.GetComponent<AudioSource>();
            audioSource.PlayOneShot(audioclip);
        }
    }
    void RunDisapperAnimation(LianLianLeItemInfo infoSel, LianLianLeItemInfo info)
    {
        iTween.MoveTo(infoSel.obj, info.obj.transform.position, 0.8f);
    }


    void LoadGame()
    {
        // gameLianLianLe.listItem = listItem;
        gameLianLianLe.infoGuanka = GameGuankaParse.main.GetItemInfo();
        gameLianLianLe.iDelegate = this;
        gameLianLianLe.LoadGame();

    }


    public void OnGameDidWin(GameBase g)
    {
        OnGameWin();
    }
    public void OnGameDidFail(GameBase g)
    {

    }
    public void OnGameUpdateTitle(GameBase g, ItemInfo info, bool isshow)
    {

    }

    public void OnGameWin()
    {
        //show game win
        LevelManager.main.gameLevelFinish = LevelManager.main.gameLevel;
        //gameEndParticle.Play();


        //Invoke("ShowGameWin", 1f);
        ShowGameWin();
        OnGameWinBase();
        //   ShowAdInsert(GAME_AD_INSERT_SHOW_STEP);
    }


    void ShowUserGuide()
    {

        if (Common.isMonoPlayer)
        {
            return;
        }
        string pkey = AppString.STR_KEY_USER_GUIDE + Common.GetAppVersion();
        bool isshowplay = Common.GetBool(pkey);
        if (isshowplay == true)
        {
            return;
        }


        {
            string title = Language.main.GetString(AppString.STR_UIVIEWALERT_TITLE_USER_GUIDE);
            string msg = Language.main.GetString(AppString.STR_UIVIEWALERT_MSG_USER_GUIDE);
            string yes = Language.main.GetString(AppString.STR_UIVIEWALERT_YES_USER_GUIDE);
            string no = yes;
            ViewAlertManager.main.ShowFull(title, msg, yes, no, false, STR_KEYNAME_VIEWALERT_USER_GUIDE, OnUIViewAlertFinished);
        }

    }

    void ShowGameWin()
    {
        Debug.Log("ShowGameWin");

        string title = Language.main.GetString(AppString.STR_UIVIEWALERT_TITLE_GAME_FINISH);
        string msg = Language.main.GetString(AppString.STR_UIVIEWALERT_MSG_GAME_FINISH);
        string yes = Language.main.GetString(AppString.STR_UIVIEWALERT_YES_GAME_FINISH);
        string no = Language.main.GetString(AppString.STR_UIVIEWALERT_NO_GAME_FINISH);
        ViewAlertManager.main.ShowFull(title, msg, yes, no, false, STR_KEYNAME_VIEWALERT_GAME_FINISH, OnUIViewAlertFinished);

    }
    void OnUIViewAlertFinished(UIViewAlert alert, bool isYes)

    {
        if (STR_KEYNAME_VIEWALERT_GAME_FINISH == alert.keyName)
        {
            if (isYes)
            {
                LevelManager.main.GotoNextLevel();
            }
            else
            {

            }
        }


        if (STR_KEYNAME_VIEWALERT_GAME_FINISH == alert.keyName)
        {

            string pkey = AppString.STR_KEY_USER_GUIDE + Common.GetAppVersion();
            Common.SetBool(pkey, true);
        }


    }
    public override void OnClickBtnBack()
    {
        base.OnClickBtnBack();
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class LianLianLeItemInfo : ItemInfo
{
    public string colorid;
    public List<object> listPic0;
    public List<object> listPic1;
    public List<object> listColorFilter;
    public Vector3 posNormalWorld;
    public int count;
    public bool isColor;
}

public class UIGameLianLianLe : UIGameBase, IGameDelegate
{ 
    public const int GUANKA_ITEM_NUM_ONE_GROUP = 5;
    public GameObject objTopBar;
    public Text textTitle;
    public Image imageBar;

    static public List<object> listAutoGuanka;//item index list
    AutoMakeGuanka autoMakeGuanka;
 

    List<object> listBg;

    List<object> listColorShow;
    List<object> listItem;
    bool isItemHasSel;
    Vector2 ptDownScreen;
    Vector3 posItemWorld;
    LianLianLeItemInfo itemInfoSel; 
    float heightImageBarNormal; 
    public static string keyGameGuide;

    GameLianLianLe gameLianLianLePrefab;
    GameLianLianLe gameLianLianLe;

    void Awake()
    {
        LoadPrefab(); 
        InitLanguage();
        ParseGuanka();

    }


    // Use this for initialization
    void Start()
    {
        UpdateGuankaLevel(GameManager.gameLevel);

    }

    // Update is called once per frame 
    void Update()
    {

        if (Input.GetKeyUp(KeyCode.Escape))
        {
            OnClickBtnBack();
        }
    }

    void LoadPrefab()
    {
        {
            GameObject obj = (GameObject)Resources.Load("App/Prefab/Game/GameLianLianLe");
            if (obj != null)
            {
                gameLianLianLePrefab = obj.GetComponent<GameLianLianLe>();

            }

        }

    }
    public override void UpdateGuankaLevel(int level)
    {
        base.UpdateGuankaLevel(level);

        AppSceneBase.main.ClearMainWorld();
        {
            gameLianLianLe = (GameLianLianLe)GameObject.Instantiate(gameLianLianLePrefab);
            AppSceneBase.main.AddObjToMainWorld(gameLianLianLe.gameObject);
            UIViewController.ClonePrefabRectTransform(gameLianLianLePrefab.gameObject, gameLianLianLe.gameObject);
            gameLianLianLe.transform.localPosition = new Vector3(0f, 0f, -1f);

        }
        LoadGame();
        //必须在LoadGame之后执行 
        LoadBg();

        UpdateTitle();

        LayOut();

        ShowUserGuide();
        Invoke("OnUIDidFinish", 2f);
    }

    static public void InitLanguage()
    {
        if (languageGame != null)
        {
            languageGame.SetLanguage(Language.main.GetLanguage());
            return;
        }
        languageGame = new Language();
        languageGame.Init(Common.GAME_RES_DIR + "/language/language.csv");
        languageGame.SetLanguage(Language.main.GetLanguage());
    }



    public override void LayOut()
    {

    }
    void UpdateTitle()
    {
        string str = StringOfItem(GetItemInfo());
        textTitle.text = str;
        RectTransform rctranTopbar = objTopBar.transform as RectTransform;

        int fontsize = textTitle.fontSize;
        int str_w = (int)Common.GetStringLength(str, AppString.STR_FONT_NAME, fontsize);

        int disp_w = (int)rctranTopbar.rect.width;
        int str_line = str_w / disp_w;
        if ((str_w % disp_w) != 0)
        {
            str_line++;
        }

        RectTransform rctran = imageBar.transform as RectTransform;

        Vector2 sizeDelta = rctran.sizeDelta;
        float oft = 0;
        sizeDelta.x = str_w + fontsize + oft * 2;
        if (sizeDelta.x > disp_w)
        {
            sizeDelta.x = disp_w;
        }
        sizeDelta.y = heightImageBarNormal;
        if (str_line > 2)
        {
            sizeDelta.y = heightImageBarNormal * str_line / 2;
        }

        rctran.sizeDelta = sizeDelta;


        RectTransform rctranTitle = textTitle.transform as RectTransform;
        Vector2 sizeDeltaTitle = rctranTitle.sizeDelta;
        sizeDeltaTitle.y = sizeDelta.y;
        rctranTitle.sizeDelta = sizeDeltaTitle;

        TTS.main.Speak(str);
    }
    bool IsInColorFilter(LianLianLeItemInfo colorfilter, LianLianLeItemInfo info)
    {
        bool isfilter = false;
        foreach (LianLianLeItemInfo infocolor in colorfilter.listColorFilter)
        {
            if (info.id == infocolor.id)
            {
                isfilter = true;
                break;
            }
        }
        return isfilter;
    }

    void LoadBg()
    {
        AppSceneBase.main.UpdateWorldBg(AppRes.IMAGE_GAME_BG);
    }


    string StringOfItem(LianLianLeItemInfo info)
    {

        ItemInfo infoplace = GameManager.main.GetPlaceItemInfo(GameManager.placeLevel);
        //STR_PLACE_LIVINGROOM_GUANKA0
        string key = keyGameGuide;//infoplace.title + "_GUANKA" + GameManager.gameLevel;
        Debug.Log("key=" + key);
        if (Common.BlankString(key))
        {
            return "";
        }
        if (languageGame == null)
        {
            return "";
        }

        string str = languageGame.GetString(key);

        return str;
    }
    void PlayAudioItem(AudioClip audioclip)
    {
        //AudioPlayer对象在场景切换后可能从当前scene移除了
        GameObject audioPlayer = GameObject.Find("AudioPlayer");
        if (audioPlayer != null)
        {
            AudioSource audioSource = audioPlayer.GetComponent<AudioSource>();
            audioSource.PlayOneShot(audioclip);
        }
    }
    void RunDisapperAnimation(LianLianLeItemInfo infoSel, LianLianLeItemInfo info)
    {
        iTween.MoveTo(infoSel.obj, info.obj.transform.position, 0.8f);
    }

    LianLianLeItemInfo GetItemInfo()
    {
        int idx = GameManager.gameLevel;
        if (listGuanka == null)
        {
            return null;
        }
        if (idx >= listGuanka.Count)
        {
            return null;
        }
        LianLianLeItemInfo info = listGuanka[idx] as LianLianLeItemInfo;
        return info;
    }



    public override int GetGuankaTotal()
    {
        int count = ParseGuanka();
        return count;
    }

    public override void CleanGuankaList()
    {
        if (listGuanka != null)
        {
            listGuanka.Clear();
        }

    }

    void ParseBgList()
    {
        if ((listBg != null) && (listBg.Count != 0))
        {
            return;
        }
        listBg = new List<object>();
        string fileName = Common.GAME_RES_DIR + "/image/bg/bg.json";
        //FILE_PATH
        string json = FileUtil.ReadStringAsset(fileName);//((TextAsset)Resources.Load(fileName, typeof(TextAsset))).text;
        JsonData root = JsonMapper.ToObject(json);
        JsonData items = root["list"];
        for (int i = 0; i < items.Count; i++)
        {
            LianLianLeItemInfo info = new LianLianLeItemInfo();
            JsonData item = items[i];
            string strdir = Common.GAME_RES_DIR + "/image/bg";
            info.pic = strdir + "/" + (string)item["pic"];
            info.listColorFilter = new List<object>();
            JsonData colorFilter = item["color_filter"];
            for (int j = 0; j < colorFilter.Count; j++)
            {
                JsonData itemtmp = colorFilter[j];
                LianLianLeItemInfo infotmp = new LianLianLeItemInfo();
                infotmp.id = (string)itemtmp["color_id"];
                info.listColorFilter.Add(infotmp);

            }
            listBg.Add(info);
        }
    }

    void AddItemImage(List<object> list, ItemInfo infoId, bool enable_color)
    {
        ItemInfo infoPlace = GameManager.main.GetPlaceItemInfo(GameManager.placeLevel);
        LianLianLeItemInfo infopic = new LianLianLeItemInfo();
        infopic.id = infoId.id;
        infopic.pic = infoId.pic;
        infopic.category = infoPlace.id;
        infopic.isColor = false;

        //随机打乱
        int rdm = Random.Range(0, list.Count + 1);

        if (enable_color)
        {
            int rdm_tmp = Random.Range(0, 2);
            bool is_up = (rdm_tmp == 0) ? true : false;
            if (rdm > list.Count / 2)
            {
                infopic.isColor = is_up;
            }
            else
            {
                infopic.isColor = !is_up;
            }
        }
        list.Insert(rdm, infopic);
    }

    void ParseAutoGuanka()
    {
        if (autoMakeGuanka == null)
        {
            // autoMakeGuanka = this.gameObject.AddComponent<AutoMakeGuanka>();
            autoMakeGuanka = new AutoMakeGuanka();
            autoMakeGuanka.Init();
            listAutoGuanka = autoMakeGuanka.ParseAutoGuankaJson();
        }

        ItemInfo infoPlace = GameManager.main.GetPlaceItemInfo(GameManager.placeLevel);
        keyGameGuide = "STR_GAME_GUIDE_" + infoPlace.id;
        ParseGuankaItemId(GUANKA_ITEM_NUM_ONE_GROUP);
        int group = listGuankaItemId.Count / GUANKA_ITEM_NUM_ONE_GROUP;
        int idx = 0;
        int count = listAutoGuanka.Count;
        for (int g = 0; g < group; g++)
        {

            for (int i = 0; i < count; i++)
            {
                LianLianLeItemInfo infoAutoGuanka = listAutoGuanka[i] as LianLianLeItemInfo;
                string strcontent = infoAutoGuanka.id;
                string[] strArray = strcontent.Split(',');

                LianLianLeItemInfo info = new LianLianLeItemInfo();
                info.listPic0 = new List<object>();
                info.listPic1 = new List<object>();
                string strDirPic = Common.GAME_RES_DIR + "/image/" + infoPlace.id;
                //pics0 
                int pos_index = 0;
                idx = 0;
                foreach (string stritem in strArray)
                {
                    idx = Common.String2Int(stritem) + g * GUANKA_ITEM_NUM_ONE_GROUP;
                    ItemInfo infoId = listGuankaItemId[idx] as ItemInfo;
                    int rdm = Random.Range(0, 2);
                    bool enable_color = (rdm == 0) ? true : false;
                    AddItemImage(info.listPic0, infoId, enable_color);
                    AddItemImage(info.listPic1, infoId, !enable_color);

                    pos_index++;
                }




                listGuanka.Add(info);
            }

        }

    }
    void ParseGuankaJson()
    {
        if ((listGuanka != null) && (listGuanka.Count != 0))
        {
            return;
        }

        listGuanka = new List<object>();
        int idx = GameManager.placeLevel;
        ItemInfo infoPlace = GameManager.main.GetPlaceItemInfo(GameManager.placeLevel);
        string fileName = Common.GAME_RES_DIR + "/guanka/item_" + infoPlace.id + ".json";
        if (idx > 5)
        {
            ParseAutoGuanka();
            return;
        }
        //FILE_PATH
        string json = FileUtil.ReadStringAsset(fileName);//((TextAsset)Resources.Load(fileName, typeof(TextAsset))).text;
                                                         // Debug.Log("json::"+json);
        JsonData root = JsonMapper.ToObject(json);
        JsonData items = root["items"];

        keyGameGuide = "STR_PLACE_" + infoPlace.id + "_GUANKA" + GameManager.gameLevel;
        for (int i = 0; i < items.Count; i++)
        {
            LianLianLeItemInfo info = new LianLianLeItemInfo();
            JsonData item = items[i];
            info.listPic0 = new List<object>();
            info.listPic1 = new List<object>();
            string strDirPic = Common.GAME_RES_DIR + "/image/" + infoPlace.id;
            JsonData jsonPic0 = item["pics0"];
            foreach (JsonData item_pic in jsonPic0)
            {
                LianLianLeItemInfo infopic = new LianLianLeItemInfo();
                infopic.pic = strDirPic + "/" + (string)item_pic["name"];
                infopic.category = (string)item_pic["type"];
                //随机打乱
                int rdm = Random.Range(0, info.listPic0.Count + 1);
                info.listPic0.Insert(rdm, infopic);
                if (Common.BlankString(info.pic))
                {
                    info.pic = infopic.pic;
                }

            }


            JsonData jsonPic1 = item["pics1"];
            foreach (JsonData item_pic in jsonPic1)
            {
                LianLianLeItemInfo infopic = new LianLianLeItemInfo();
                infopic.pic = strDirPic + "/" + (string)item_pic["name"];
                infopic.category = (string)item_pic["type"];
                //随机打乱
                int rdm = Random.Range(0, info.listPic1.Count + 1);
                info.listPic1.Insert(rdm, infopic);
            }


            listGuanka.Add(info);
        }

    }




    public override int ParseGuanka()
    {
        ParseBgList();
        ParseGuankaJson();
        int count = listGuanka.Count;
        return count;

    }
  

    void LoadGame()
    {
        // gameLianLianLe.listItem = listItem;
        gameLianLianLe.infoGuanka = GetItemInfo();
        gameLianLianLe.iDelegate = this;
        gameLianLianLe.LoadGame();

    }


    public void OnGameDidWin(GameBase g)
    {
        OnGameWin();
    }
    public void OnGameDidFail(GameBase g)
    {

    }
 
    public void OnGameWin()
    {
        //show game win
        GameManager.gameLevelFinish = GameManager.gameLevel;
        //gameEndParticle.Play();


        //Invoke("ShowGameWin", 1f);
        ShowGameWin();
        OnGameWinBase();
        //   ShowAdInsert(GAME_AD_INSERT_SHOW_STEP);
    }


    void ShowUserGuide()
    {

        if (Common.isMonoPlayer)
        {
            return;
        }
        string pkey = AppString.STR_KEY_USER_GUIDE + Common.GetAppVersion();
        bool isshowplay = Common.GetBool(pkey);
        if (isshowplay == true)
        {
            return;
        }


        {
            string title = Language.main.GetString(AppString.STR_UIVIEWALERT_TITLE_USER_GUIDE);
            string msg = Language.main.GetString(AppString.STR_UIVIEWALERT_MSG_USER_GUIDE);
            string yes = Language.main.GetString(AppString.STR_UIVIEWALERT_YES_USER_GUIDE);
            string no = yes;
            ViewAlertManager.main.ShowFull(title, msg, yes, no, false, STR_KEYNAME_VIEWALERT_USER_GUIDE, OnUIViewAlertFinished);
        }

    }

    void ShowGameWin()
    {
        Debug.Log("ShowGameWin");

        string title = Language.main.GetString(AppString.STR_UIVIEWALERT_TITLE_GAME_FINISH);
        string msg = Language.main.GetString(AppString.STR_UIVIEWALERT_MSG_GAME_FINISH);
        string yes = Language.main.GetString(AppString.STR_UIVIEWALERT_YES_GAME_FINISH);
        string no = Language.main.GetString(AppString.STR_UIVIEWALERT_NO_GAME_FINISH);
        ViewAlertManager.main.ShowFull(title, msg, yes, no, false, STR_KEYNAME_VIEWALERT_GAME_FINISH, OnUIViewAlertFinished);

    }
    void OnUIViewAlertFinished(UIViewAlert alert, bool isYes)

    {
        if (STR_KEYNAME_VIEWALERT_GAME_FINISH == alert.keyName)
        {
            if (isYes)
            {
                GameManager.main.GotoNextLevel();
            }
            else
            {

            }
        }


        if (STR_KEYNAME_VIEWALERT_GAME_FINISH == alert.keyName)
        {

            string pkey = AppString.STR_KEY_USER_GUIDE + Common.GetAppVersion();
            Common.SetBool(pkey, true);
        }


    }
    public override void OnClickBtnBack()
    {
        base.OnClickBtnBack();
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class GameLianLianLe : GameBase
{
    /// <summary>
    /// Awake is called when the script instance is being loaded.
    /// </summary> 
    public const int TAG_ITEM_LOCK = -1;
    public const int TAG_ITEM_UNLOCK = 0;

    List<object> listColorShow;
    bool isItemHasSel;
    Vector2 ptDownScreen;
    Vector3 posItemWorld;
    LianLianLeItemInfo itemInfoSel;
    float itemPosZ = -20f;

    Shader shaderColor;
    UITouchEventWithMove uiTouchEvent;
    BoxCollider boxCollider;
    public LianLianLeItemInfo infoGuanka;
    void Awake()
    {
        shaderColor = Shader.Find("Custom/ShapeColor");
        uiTouchEvent = this.gameObject.AddComponent<UITouchEventWithMove>();
        uiTouchEvent.callBackTouch = OnUITouchEvent;
        Vector2 worldsize = Common.GetWorldSize(mainCam);
        boxCollider = this.gameObject.AddComponent<BoxCollider>();
        boxCollider.size = worldsize;
    }


    // Use this for initialization
    void Start()
    {
    }


    public void OnUITouchEvent(UITouchEvent ev, PointerEventData eventData, int status)
    {
        switch (status)
        {
            case UITouchEvent.STATUS_TOUCH_DOWN:
                {
                    onTouchDown();
                }
                break;
            case UITouchEvent.STATUS_TOUCH_MOVE:
                {
                    onTouchMove();
                }
                break;
            case UITouchEvent.STATUS_TOUCH_UP:
                {
                    onTouchUp();
                }
                break;

        }
    }
    void onTouchDown()
    {


        isItemHasSel = false;
        Vector2 pos = Common.GetInputPosition();
        ptDownScreen = pos;

        Vector3 posword = mainCam.ScreenToWorldPoint(pos);
        Debug.Log("onTouchDown: " + posword);
        foreach (LianLianLeItemInfo info in listItem)
        {
            bool isLock = IsItemLock(info);
            if (isLock)
            {
                continue;
            }

            Bounds bd = info.obj.GetComponent<SpriteRenderer>().bounds;

            posword.z = bd.center.z;
            Rect rc = new Rect(info.obj.transform.position.x - bd.size.x / 2, info.obj.transform.position.y - bd.size.y / 2, bd.size.x, bd.size.y);
            //Debug.Log("left:"+bd+"rc="+rc);
            if (rc.Contains(posword))
            {

                posItemWorld = info.obj.transform.position;
                itemInfoSel = info;
                isItemHasSel = true;
                int status = GetGameItemStatus(info);
                if (status == GAME_STATUS_UN_START)
                {
                    SetGameItemStatus(info, GAME_STATUS_PLAY);
                }
                break;
            }
        }


    }
    void onTouchMove()
    {
        if (!isItemHasSel)
        {
            Debug.Log("onTouchMove ng 1");
            return;
        }
        bool isLock = IsItemLock(itemInfoSel);
        if (isLock)
        {
            Debug.Log("onTouchMove ng 2");
            return;
        }
        float x, y, w, h;
        Vector2 pos = Common.GetInputPosition();

        Vector2 ptStep = pos - ptDownScreen;
        Vector2 ptStepWorld = Common.ScreenToWorldSize(mainCam, ptStep);
        Vector3 posStepWorld = new Vector3(ptStepWorld.x, ptStepWorld.y, 0);
        Vector3 posword = posItemWorld + posStepWorld;

        //将选中item暂时置顶
        posword.z = itemPosZ - 1;
        itemInfoSel.obj.transform.position = posword;


        foreach (LianLianLeItemInfo info in listItem)
        {
            isLock = IsItemLock(info);
            if (isLock)
            {
                //  Debug.Log("onTouchMove ng 3");
                // continue;
            }

            if (info == itemInfoSel)
            {
                continue;
            }
            Bounds bd = info.obj.GetComponent<SpriteRenderer>().bounds;

            posword.z = bd.center.z;
            w = bd.size.x / 4;
            h = bd.size.y / 4;
            Rect rc = new Rect(info.obj.transform.position.x - w / 2, info.obj.transform.position.y - h / 2, w, h);
            //Debug.Log("left:"+bd+"rc="+rc);
            if ((rc.Contains(posword)) && (itemInfoSel.category == info.category))
            {
                Debug.Log("合并正确");
                //合并正确
                SetItemLock(info, true);
                SetItemLock(itemInfoSel, true);

                RunDisapperAnimation(itemInfoSel, info);

                bool isAllItemLock = IsAllItemLock();
                if (!isAllItemLock)
                {

                    AudioPlay.main.PlayFile(AppRes.AUDIO_DragOk);
                }


                break;
            }
        }

        CheckGameWin();

    }
    void onTouchUp()
    {
        if (!isItemHasSel)
        {
            return;
        }
        bool isLock = IsItemLock(itemInfoSel);
        if (isLock)
        {
            return;
        }

        //将选中item还原位置
        Vector3 pos = itemInfoSel.posNormalWorld;
        iTween.MoveTo(itemInfoSel.obj, pos, 0.8f);
        AudioPlay.main.PlayFile(AppRes.AUDIO_DragFail);
    }

    public override void LayOut()
    {
        if (boxCollider != null)
        {
            Vector2 worldsize = Common.GetWorldSize(mainCam);
            boxCollider.size = worldsize;
        }
    }
    bool IsInColorFilter(LianLianLeItemInfo colorfilter, LianLianLeItemInfo info)
    {
        bool isfilter = false;
        foreach (LianLianLeItemInfo infocolor in colorfilter.listColorFilter)
        {
            if (info.id == infocolor.id)
            {
                isfilter = true;
                break;
            }
        }
        return isfilter;
    }



    void RunDisapperAnimation(LianLianLeItemInfo infoSel, LianLianLeItemInfo info)
    {
        iTween.MoveTo(infoSel.obj, info.obj.transform.position, 0.8f);
    }

    void SetItemLock(ItemInfo info, bool isLock)
    {
        if (isLock)
        {
            info.tag = TAG_ITEM_LOCK;
        }
        else
        {
            info.tag = TAG_ITEM_UNLOCK;
        }
    }
    bool IsItemLock(ItemInfo info)
    {
        bool ret = false;
        if (info.tag == TAG_ITEM_LOCK)
        {
            ret = true;
        }
        return ret;
    }

    float GetItmeScaleInRect(Rect rc, GameObject obj)
    {
        float scale = 1f;
        SpriteRenderer objSR = obj.GetComponent<SpriteRenderer>();
        Bounds bd = objSR.bounds;
        float ratio = 0.7f;
        float scalex = rc.width * ratio / bd.size.x;
        float scaley = rc.height * ratio / bd.size.y;
        scale = Mathf.Min(scalex, scaley);
        if (scale > 1f)
        {
            // scale = 1f;
        }
        return scale;
    }
    Rect GetRectItem(int i, int j, int totalRow, int totalCol)
    {
        Vector2 sizeCanvas = AppSceneBase.main.sizeCanvas;
        Rect rc = Rect.zero;
        float x, y, w, h;
        float w_world = Common.GetCameraWorldSizeWidth(mainCam) * 2;
        float height_topbar_canvas = 160f;
        float height_ad_canvas = 128f;
        float height_topbar_world = Common.CanvasToWorldHeight(mainCam, sizeCanvas, height_topbar_canvas);
        float height_ad_world = Common.CanvasToWorldHeight(mainCam, sizeCanvas, height_ad_canvas);

        float h_world = mainCam.orthographicSize * 2;
        w = w_world / totalCol;
        h = (h_world - height_topbar_world - height_ad_world) / totalRow;
        float oftx = -w_world / 2;
        float ofty = -h_world / 2 + height_ad_world;
        x = oftx + w * i;
        y = ofty + h * j;
        rc = new Rect(x, y, w, h);
        return rc;
    }
    Vector2 RandomPointOfRect(Rect rc, float offsetx, float offsety)
    {
        float x, y, w, h;
        w = rc.width - offsetx * 2;
        h = rc.height - offsety * 2;
        int rdx = Random.Range(0, 99);
        //rdx = 50;
        x = rc.x + (offsetx + w * rdx / 100);

        rdx = Random.Range(0, 99);

        //rdx = 50;
        y = rc.y + (offsety + h * rdx / 100);


        return new Vector2(x, y);
    }

    //从数组里随机抽取newsize个元素
    int[] RandomIndex(int size, int newsize)
    {
        List<object> listIndex = new List<object>();
        int total = size;
        for (int i = 0; i < total; i++)
        {
            listIndex.Add(i);
        }

        int[] idxTmp = new int[newsize];
        for (int i = 0; i < newsize; i++)
        {
            total = listIndex.Count;
            int rdm = Random.Range(0, total);
            int idx = (int)listIndex[rdm];
            idxTmp[i] = idx;
            listIndex.RemoveAt(rdm);
        }

        return idxTmp;
    }

    GameObject CreateItem(LianLianLeItemInfo info)
    {
        float x, y, w, h;
        string name = FileUtil.GetFileName(info.pic);


        GameObject obj = new GameObject(name);
        obj.transform.SetParent(this.gameObject.transform);
        RectTransform rcTran = obj.AddComponent<RectTransform>();
        SpriteRenderer objSR = obj.AddComponent<SpriteRenderer>();
        string pic = info.pic;
        Sprite sprite = LoadTexture.CreateSprieFromAsset(pic);
        sprite.name = info.id;
        objSR.sprite = sprite;
        //rcTran.sizeDelta = new Vector2(objSR.size.x, objSR.size.y);

        obj.transform.position = new Vector3(0, 0, itemPosZ);
        SetItemLock(info, false);

        return obj;
    }


    int CalcRowCol(int total)
    {
        int sqr = (int)Mathf.Sqrt(total);
        if (total > sqr * sqr)
        {
            sqr++;
        }
        return sqr;
    }
    void AddItem(Rect rc, LianLianLeItemInfo info, GameObject obj)
    {
        LianLianLeItemInfo infoItem = new LianLianLeItemInfo();
        infoItem.obj = obj;
        infoItem.category = info.category;

        listItem.Add(infoItem);


        float scale = GetItmeScaleInRect(rc, obj);
        obj.transform.localScale = new Vector3(scale, scale, 1f);


        SpriteRenderer objSR = obj.GetComponent<SpriteRenderer>();
        Bounds bd = objSR.bounds;
        float offsetx = bd.size.x / 2;
        //offsetx =0;
        float offsety = bd.size.y / 2;
        //offsety=0;
        Vector2 pt = rc.center;//RandomPointOfRect(rc, offsetx, offsety);

        infoItem.posNormalWorld = new Vector3(pt.x, pt.y, obj.transform.position.z);
        obj.transform.position = infoItem.posNormalWorld;

        if (info.isColor)
        {
            Material mat = new Material(shaderColor);
            objSR.material = mat;
            mat.SetColor("_ColorShape", Color.red);
        }

    }

    public void LoadGame()
    {


        if (listItem != null)
        {
            listItem.Clear();
        }
        else
        {
            listItem = new List<object>();
        }

        if (listColorShow == null)
        {
            listColorShow = new List<object>();
        }
        else
        {
            listColorShow.Clear();
        }

        int level = LevelManager.main.gameLevel;
        LianLianLeItemInfo info = infoGuanka;
        if (info == null)
        {
            Debug.Log("LoadGame null");
            return;
        }

        int totalRow = 2;
        int totalCol = info.listPic0.Count;
        if (!Device.isLandscape)
        {
            totalRow = info.listPic0.Count;
            totalCol = 2;
        }
        List<object> listPic = info.listPic0;
        for (int k = 0; k < listPic.Count; k++)
        {
            GameObject obj = null;
            LianLianLeItemInfo infopic = listPic[k] as LianLianLeItemInfo;
            obj = CreateItem(infopic);
            int i = k;
            int j = 0;
            if (!Device.isLandscape)
            {
                i = 0;
                j = k;
            }
            Rect rc = GetRectItem(i, j, totalRow, totalCol);
            AddItem(rc, infopic, obj);
        }

        listPic = info.listPic1;
        for (int k = 0; k < listPic.Count; k++)
        {
            GameObject obj = null;
            LianLianLeItemInfo infopic = listPic[k] as LianLianLeItemInfo;
            obj = CreateItem(infopic);
            int i = k;
            int j = 1;
            if (!Device.isLandscape)
            {
                i = 1;
                j = k;
            }
            Rect rc = GetRectItem(i, j, totalRow, totalCol);
            AddItem(rc, infopic, obj);
        }

    }



    bool IsAllItemLock()
    {
        bool isAllItemLock = true;

        foreach (LianLianLeItemInfo info in listItem)
        {

            bool isLock = IsItemLock(info);
            if (!isLock)
            {
                isAllItemLock = false;
            }

        }
        return isAllItemLock;

    }

    void CheckGameWin()
    {
        bool isAllItemLock = IsAllItemLock();

        if (isAllItemLock)
        {
            //show game win
            // gameEndParticle.Play();

            foreach (LianLianLeItemInfo info in listItem)
            {
                SetGameItemStatus(info, GAME_STATUS_FINISH);
            }
            Invoke("OnGameWin", 1f);
            AudioPlay.main.PlayFile(AppRes.AUDIO_GuankaOk);
        }

    }



}

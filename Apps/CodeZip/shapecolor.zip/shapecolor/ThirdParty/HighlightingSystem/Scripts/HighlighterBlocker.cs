﻿using UnityEngine;
using System.Collections;

namespace HighlightingSystem
{
	[AddComponentMenu("Highlighting System/Highlighter Blocker", 1)]
	public class HighlighterBlocker : MonoBehaviour
	{

	}
}
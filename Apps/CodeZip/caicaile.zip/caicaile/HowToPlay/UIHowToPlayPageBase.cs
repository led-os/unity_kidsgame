using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class UIHowToPlayPageBase : UIView
{
    public float width;
    public float heigt;
    public int index;


    /// <summary>
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    void Awake()
    {
    }
    void Start()
    {

    }

    public override void LayOut()
    {

    }

    public virtual void OnPageExit()
    {

    }
    public virtual void OnPageEnter()
    {

    }

}

﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Text;


public class GameLevelParseBase : LevelParseBase
{
    public virtual void ParseItem(CaiCaiLeItemInfo info)
    {


    }

    public virtual void ParseItemDetal(CaiCaiLeItemInfo info)
    {


    }
    
}

using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class UIHowPlayFlowerPage3 : UIHowPlayFlowerPage
{
 
    /// <summary>
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    void Awake()
    {
       base.Awake();
    }
    void Start()
    {
        LayOut();
    }

    public override void LayOut()
    {
        base.LayOut();
    }

    public override void OnPageExit()
    {

    }
    public override void OnPageEnter()
    {

    }
}

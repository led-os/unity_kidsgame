﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using LitJson;
using UnityEditor;
using System.Text;


public class FlowerEditorJsonItemInfo
{
    public string row;
    public string col;
}

public class FlowerEditorItemInfo
{
    public int index;
    public int row;
    public int col;
}
public class EditorIdiomFlower : Editor
{
    static public int rowTotal;
    static public int colTotal;
    static public int totalIdiom;
    static public FlowerEditorItemInfo infoSeed;
    static public List<FlowerEditorItemInfo> listItemSel;//选中 
    [MenuItem("CaiCaiLe/MakeIdiomFlowerData")]
    static void OnMakeIdiomFlowerData()
    {
        rowTotal = 4;
        colTotal = 4;
        totalIdiom = rowTotal * colTotal / 4;
        listItemSel = new List<FlowerEditorItemInfo>();

        int total = 1000;
        int count = 0;
        while (count < total)
        {
            bool ret = MakeIdiomFlowerData();
            if (ret)
            {
                SaveJson(count);
                count++;
            }
        }


    }

    static void SaveJson(int idx)
    {
        //save guanka json
        List<FlowerEditorJsonItemInfo> listJson = new List<FlowerEditorJsonItemInfo>();
        foreach (FlowerEditorItemInfo info in listItemSel)
        {
            FlowerEditorJsonItemInfo infojson = new FlowerEditorJsonItemInfo();
            infojson.row = info.row.ToString();
            infojson.col = info.col.ToString();
            listJson.Add(infojson);
        }
        Hashtable data = new Hashtable();
        data["items"] = listJson;
        string strJson = JsonMapper.ToJson(data);
        string dir = Application.streamingAssetsPath + "/" + Common.GAME_RES_DIR + "/guanka/data";
        FileUtil.CreateDir(dir);
        string filepath = dir + "/item_" + idx.ToString() + ".json";
        byte[] bytes = Encoding.UTF8.GetBytes(strJson);
        System.IO.File.WriteAllBytes(filepath, bytes);

    }
    static bool MakeIdiomFlowerData()
    {
        bool ret = true;
        FlowerEditorItemInfo infoSeed = null;
        bool isError = false;
        listItemSel.Clear();
        for (int i = 0; i < rowTotal * colTotal; i++)
        {
            if (listItemSel.Count % 4 == 0)
            {
                //成语的开头
                infoSeed = GetSeed();
            }
            if (infoSeed == null)
            {
                //ng
                isError = true;
                break;
            }
            List<FlowerEditorItemInfo> listSide = GetSideItems(infoSeed.row, infoSeed.col);
            if (listSide.Count == 0)
            {
                //ng
                isError = true;
                break;
            }

            int idx = Random.Range(0, listSide.Count);
            FlowerEditorItemInfo info = listSide[idx];
            listItemSel.Add(info);
            infoSeed = info;

        }

        if (isError)
        {
            if (listItemSel.Count < totalIdiom * 4)
            {
                // fail
                ret = false;
            }
        }
        return ret;
    }
    static FlowerEditorItemInfo GetSeed()
    {
        List<FlowerEditorItemInfo> list = new List<FlowerEditorItemInfo>();
        for (int i = 0; i < rowTotal; i++)
        {
            for (int j = 0; j < colTotal; j++)
            {
                if (!IsItemHasSel(i, i))
                {
                    FlowerEditorItemInfo info = new FlowerEditorItemInfo();
                    info.row = i;
                    info.col = j;
                    list.Add(info);
                }
            }
        }
        if (list.Count > 0)
        {
            int idx = Random.Range(0, list.Count);
            return list[idx];
        }
        return null;
    }
    static bool IsItemHasSel(int row, int col)
    {
        bool ret = false;
        foreach (FlowerEditorItemInfo info in listItemSel)
        {
            if ((info.row == row) && (info.col == col))
            {
                ret = true;
                break;
            }
        }
        return ret;
    }

    static void AddItem(List<FlowerEditorItemInfo> list, int r, int c)
    {
        if (!IsItemHasSel(r, c))
        {
            FlowerEditorItemInfo info = new FlowerEditorItemInfo();
            info.row = r;
            info.col = c;
            list.Add(info);
        }
    }
    //获取相邻的item
    static List<FlowerEditorItemInfo> GetSideItems(int row, int col)
    {

        int r, c;
        r = row;
        c = col;
        List<FlowerEditorItemInfo> list = new List<FlowerEditorItemInfo>();
        //左
        {
            c--;
            if (c >= 0)
            {
                AddItem(list, r, c);
            }
        }
        //右
        {
            c++;
            if (c < colTotal)
            {
                AddItem(list, r, c);
            }
        }
        //上
        {
            r++;
            if (r < rowTotal)
            {
                AddItem(list, r, c);
            }
        }
        //下
        {
            r--;
            if (r >= 0)
            {
                AddItem(list, r, c);
            }
        }



        //左上
        {
            c--;
            r++;
            if ((c >= 0) && (r < rowTotal))
            {
                AddItem(list, r, c);
            }
        }
        //左下
        {
            c--;
            r--;
            if ((c >= 0) && (r >= 0))
            {
                AddItem(list, r, c);
            }
        }

        //右上
        {
            c++;
            r++;
            if ((c < colTotal) && (r < rowTotal))
            {
                AddItem(list, r, c);
            }
        }
        //右下 
        {
            c++;
            r--;
            if ((r >= 0) && (c < colTotal))
            {
                AddItem(list, r, c);
            }
        }

        return list;
    }
}

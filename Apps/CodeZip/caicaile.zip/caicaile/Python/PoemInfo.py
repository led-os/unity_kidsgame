class PoemInfo():
    title =""
    year =""
    url =""
    author =""
    content =""
    content_pinyin =""
    translation =""
    # 赏析
    appreciation =""
    authorDetail =""
    

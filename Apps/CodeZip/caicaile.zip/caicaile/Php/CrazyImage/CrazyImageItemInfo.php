﻿<?php
class CrazyImageItemInfo
{
    public $title;
    public $album;
    public $url;
    public $translation;
    public $id;
}

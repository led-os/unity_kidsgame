﻿<?php
class IdiomItemInfo
{
    public $title;
    public $album;
    public $url;
    public $translation;
    public $pinyin;
}

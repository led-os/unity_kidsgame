﻿<?php
class RiddleItemInfo
{
    public $head;
    public $end;
    public $tips;
    public $type;
    public $id;
    public $channel;
    public $url;
    
    // public function setData($height, $weight)
    // {
    //     $this->height = $height;
    //     $this->weight = $weight;
    // }


}

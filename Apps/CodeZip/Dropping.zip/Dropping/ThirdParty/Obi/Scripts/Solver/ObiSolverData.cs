using UnityEngine;
using System;
using System.Collections;

namespace Obi{
	public class ObiSolverData{
		
		
		
		public ParticleData particleData = ParticleData.NONE;
	
		public ObiSolverData(ParticleData particleData){
			this.particleData = particleData;
		}
    }
}


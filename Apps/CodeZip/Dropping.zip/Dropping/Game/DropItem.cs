﻿using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(MeshRenderer), typeof(MeshFilter))]
public class DropItem : UIView
{
    Mesh mesh;
    MeshRenderer meshRd;
    public GameObject objSpriteBg;
    void Awake()
    {
        meshRd = GetComponent<MeshRenderer>();
        mesh = GetComponent<MeshFilter>().mesh;
        meshRd.material.color = Color.red;
    }

    // Use this for initialization
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {

    }


    public void OnClickBtnItem()
    {

    }

    public override void LayOut()
    {
        Vector2 sizeCanvas = this.frame.size;
        float x = 0, y = 0, w = 0, h = 0;

    }
}

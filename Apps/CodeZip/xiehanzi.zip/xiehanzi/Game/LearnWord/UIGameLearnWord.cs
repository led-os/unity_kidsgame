﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.IO;
using Moonma.Share;
//笔画顺序查询网： https://bihua.51240.com/e68891__bihuachaxun/



public class UIGameLearnWord : UIGameBase, IGameXieHanziDelegate
{

    void Awake()
    {
        LoadPrefab();
        AppSceneBase.main.UpdateWorldBg(AppRes.IMAGE_GAME_BG);
    }
    // Use this for initialization
    void Start()
    {
        UpdateGuankaLevel(LevelManager.main.gameLevel);
    }


    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyUp(KeyCode.Escape))
        {
            OnClickBtnBack();
        }

    }

    void LoadPrefab()
    {





    }



    void InitUI()
    {



        OnUIDidFinish();
    }


    public override void UpdateGuankaLevel(int level)
    {
        base.UpdateGuankaLevel(level);
        AppSceneBase.main.ClearMainWorld();
        languageGame.SetLanguage(Language.main.GetLanguage());
        WordItemInfo infonow = GameLevelParse.main.GetItemInfo();
        long tickItem = Common.GetCurrentTimeMs();
        tickItem = Common.GetCurrentTimeMs() - tickItem;
        Debug.Log("ParserGuankaItem: tickItem=" + tickItem);



        InitUI();
    }
    public override void LayOut()
    {

    }


}

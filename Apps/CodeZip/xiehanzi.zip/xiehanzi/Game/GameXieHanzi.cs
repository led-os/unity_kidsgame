﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameXieHanzi : UIView
{
    PaintLine paintLinePrefab;
    PaintLine paintLine;

    void Awake()
    {
        LoadPrefab();
    }
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    void LoadPrefab()
    {
        GameObject obj = (GameObject)Resources.Load("App/Prefab/Game/PaintLine");
        if (obj != null)
        {
            paintLinePrefab = obj.GetComponent<PaintLine>();
            paintLine = (PaintLine)GameObject.Instantiate(paintLinePrefab);

            RectTransform rctranPrefab = paintLinePrefab.transform as RectTransform;
            paintLine.gameObject.transform.SetParent(this.transform);
            RectTransform rctran = paintLine.transform as RectTransform;
            // 初始化rect
            rctran.offsetMin = rctranPrefab.offsetMin;
            rctran.offsetMax = rctranPrefab.offsetMax;

        }

    }
}

﻿using System.Collections;
using System.Collections.Generic;
public class AppXieHanzi
{
    public const int FREE_ITEM_NUM = 8;
    //image 
    public const string RES_WORDWRITE_MODE_ALL_UNSEL = "AppCommon/Game/hanziyuan/common/btnMode1_y";
    public const string RES_WORDWRITE_MODE_ALL_SEL = "AppCommon/Game/hanziyuan/common/btnMode1";

    public const string RES_WORDWRITE_MODE_ONE_UNSEL = "AppCommon/Game/hanziyuan/common/btnMode2_y";
    public const string RES_WORDWRITE_MODE_ONE_SEL = "AppCommon/Game/hanziyuan/common/btnMode2";

    public const string RES_WORDWRITE_MODE_NONE_UNSEL = "AppCommon/Game/hanziyuan/common/btnMode3_y";
    public const string RES_WORDWRITE_MODE_NONE_SEL = "AppCommon/Game/hanziyuan/common/btnMode3";


    //string
    public const string STR_WORD_WRITE_FINISH_TITLE = "STR_WORD_WRITE_FINISH_TITLE";
    public const string STR_HISTORY_TITLE = "STR_HISTORY_TITLE";
    public const string STR_HISTORY_BTN_WORD = "STR_HISTORY_BTN_WORD";
    public const string STR_HISTORY_BTN_DATE = "STR_HISTORY_BTN_DATE";
    public const string STR_HISTORY_BTN_FREE_WRITE = "STR_HISTORY_BTN_FREE_WRITE";


    public const string STR_UIVIEWALERT_TITLE_CLEAR_DB = "STR_UIVIEWALERT_TITLE_CLEAR_DB";
    public const string STR_UIVIEWALERT_MSG_CLEAR_DB = "STR_UIVIEWALERT_MSG_CLEAR_DB";
    public const string STR_UIVIEWALERT_YES_CLEAR_DB = "STR_UIVIEWALERT_YES_CLEAR_DB";
    public const string STR_UIVIEWALERT_NO_CLEAR_DB = "STR_UIVIEWALERT_NO_CLEAR_DB";


}

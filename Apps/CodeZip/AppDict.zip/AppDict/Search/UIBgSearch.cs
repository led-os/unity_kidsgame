﻿using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Tacticsoft;
using UnityEngine;
using UnityEngine.UI;


public class UIBgSearch : UIView
{
    public UIImage imageBg;
    public UIImage imageBoard;
    public UIImage imageLeftUp;

    public UIImage imageRightUp;
    public UIImage imageRightDown;

    public void Awake()
    {
        base.Awake();

    }

    // Use this for initialization
    public void Start()
    {
        base.Start();
        LayOut();
    }

    public override void LayOut()
    {
        base.LayOut();
    }

}
